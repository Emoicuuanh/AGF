#ifndef LOCAL_TRACKING_H_
#define LOCAL_TRACKING_H_

#include <ros/ros.h>

#include <nlohmann/json.hpp>

// base local planner base class and utilities
#include <base_local_planner/costmap_model.h>
#include <base_local_planner/goal_functions.h>
#include <base_local_planner/odometry_helper_ros.h>
#include <mbf_costmap_core/costmap_controller.h>
#include <nav_core/base_local_planner.h>

// message types
#include <costmap_converter/ObstacleMsg.h>
#include <geometry_msgs/Pose2D.h>
#include <geometry_msgs/PoseStamped.h>
#include <geometry_msgs/Twist.h>
#include <nav_msgs/Odometry.h>
#include <nav_msgs/Path.h>
#include <std_msgs/Float64.h>
#include <visualization_msgs/Marker.h>
#include <agv_msgs/ArrayWaypoints.h>
#include <agv_msgs/ArrayWaypointsResponse.h>
#include <agv_msgs/WaypointSafety.h>
#include <agv_msgs/ArraySafetyWaypoints.h>
#include <agf_msgs/Int8Array.h>
#include <std_stamped_msgs/StringStamped.h>

// transforms
#include <tf2/utils.h>
#include <tf2_ros/buffer.h>

// dynamic reconfigure
#include <agf_local_planner/AgfLocalPlannerReconfigureConfig.h>
#include <dynamic_reconfigure/server.h>

// costmap
#include <costmap_2d/costmap_2d_ros.h>
#include <costmap_converter/costmap_converter_interface.h>

namespace agf_local_planner
{
class AgfLocalPlannerROS : public nav_core::BaseLocalPlanner,
                           public mbf_costmap_core::CostmapController
{
public:
  AgfLocalPlannerROS();

  ~AgfLocalPlannerROS();

  void initialize(std::string name, tf2_ros::Buffer* tf,
                  costmap_2d::Costmap2DROS* costmap_ros);

  bool setPlan(const std::vector<geometry_msgs::PoseStamped>& orig_global_plan);

  void setSafety(double distance_to_goal);

  bool computeVelocityCommands(geometry_msgs::Twist& cmd_vel);

  uint32_t computeVelocityCommands(const geometry_msgs::PoseStamped& pose,
                                   const geometry_msgs::TwistStamped& velocity,
                                   geometry_msgs::TwistStamped& cmd_vel,
                                   std::string& message);

  /**
            find point in a path that nearest with const distance with robot
             */
  void findPointInPath(const geometry_msgs::PoseStamped& pose_robot,
                       const std::vector<geometry_msgs::PoseStamped>& path,
                       geometry_msgs::PoseStamped& pose, double distance,
                       int& number_in_path);

  bool control(const geometry_msgs::PoseStamped& pose_control,
               double lookahead_dist, geometry_msgs::TwistStamped& cmd_vel,
               const geometry_msgs::PoseStamped& robot_pose);

  bool rotateCarLike(geometry_msgs::TwistStamped& cmd_vel,
                     const geometry_msgs::PoseStamped& robot_pose,
                     double diff_angle);

  bool checkRobotNearSlowPoint(const geometry_msgs::PoseStamped& pose_robot);

  int checkRobotNearSpecialSafety(const geometry_msgs::PoseStamped& pose_robot);

  double quaternionToRPY(double qx, double qy, double qz, double qw);

  double normalizeAngle(double angle);

  void cmdVelCallback(const geometry_msgs::Twist::ConstPtr msg);

  // void safetyCallback(const safety_msgs::SafetyStatus::ConstPtr msg);

  void request_speed_limit_cb(std_stamped_msgs::StringStamped::ConstPtr msg);

  void request_safety_job_cb(agf_msgs::Int8Array::ConstPtr msg);

  void setRuleSafety();

  void setDirection(std::string direction);

  void steeringAngleCallback(const std_msgs::Float64::ConstPtr msg);

  void reconfigureCB(AgfLocalPlannerReconfigureConfig& config, uint32_t level);

  bool isGoalReached();

  bool isGoalReached(double xy_tolerance, double yaw_tolerance)
  {
    return isGoalReached();
  };

  bool cancel() { return false; };

private:
  costmap_2d::Costmap2DROS* costmap_ros_;
  costmap_2d::Costmap2D* costmap_;
  tf2_ros::Buffer* tf_;

  boost::shared_ptr<base_local_planner::CostmapModel> costmap_model_;
  boost::shared_ptr<dynamic_reconfigure::Server<AgfLocalPlannerReconfigureConfig>> dynamic_recfg_;

  std::string name_;
  std::string odom_topic_;
  std::string global_frame_;
  std::string robot_base_frame_;

  geometry_msgs::PoseStamped global_goal_;
  nav_msgs::Path path_global_;
  base_local_planner::OdometryHelperRos
      odom_helper_;  // Provides an interface to receive the current velocity from the robot
  geometry_msgs::Twist
      robot_vel_;  // Store current robot translational and angular velocity (vx, vy, omega)
  agf_msgs::Int8Array msg_safety_, msg_safety_zone_;
  void resetSafetyZone();

  ros::NodeHandle nh_;
  ros::Publisher pub_path_;
  ros::Publisher pub_safety_control_;
  
  // Visualization publishers
  ros::Publisher pub_local_path_;        // Pruned path being followed
  ros::Publisher pub_lookahead_point_;   // Target lookahead point
  ros::Publisher pub_nearest_point_;     // Nearest point on path
  ros::Publisher pub_control_point_;     // Robot control point

  ros::Subscriber sub_cmd_vel_;
  ros::Subscriber sub_angle_steer_;
  ros::Subscriber sub_safety_zone_;
  ros::Subscriber request_speed_limit_sub;
  ros::Subscriber request_safety_job_sub;

  ros::ServiceClient client_get_waypoints_low_speed_;
  ros::ServiceClient client_get_waypoints_special_safety_;

  std::vector<geometry_msgs::PoseStamped> global_plan_;

  bool initialized_;
  bool goal_reached_;
  bool is_near_goal_;
  bool go_forward_;
  bool rotate_to_goal_;
  bool correcting_position_after_rotate_;  // True when fixing position drift after rotation
  bool low_speed_;
  bool is_carlike_;
  bool ignore_last_rotate_;
  bool allow_set_safety_;
  bool priority_angle_adjustment_;

  int safety_job_;

  double lookahead_dist_;              // m
  double look_forward_gain_;           // m
  double max_vel_x_;                   // Maximun of linear velocity
  double max_angular_z_;               // Maximun of angle velocity
  double angle_to_global_when_start_;  // Angle to rotate to global path
  double weight_acc_;                  // Parameter effect to acc
  double error_to_start_stop_;         // Circle around goal robot begin stop
  double error_angle_stop_;  // Error angle allow between robot and goal
  double k_p_;               // Parameter to tuning
  double
      max_error_pose_to_path_;  // Check robot far the local path if > max_error_pose_to_local_ ==> reset global planner
  double
      distance_to_control_point_;  // Distance of center robot to control point
  double old_time_;                // Use to know a loop time of control
  double new_time_;                // Use to know a loop time of control
  double dt_;                      // Loop time of control
  double steering_angle_;
  double weight_theta_e_;
  double weight_theta_d_;
  double vel_x_when_more_angle_;
  double steering_angle_for_rotate_;  // Góc bánh lái khi rotate (deprecated, use min/max)
  double steering_angle_for_rotate_min_;  // Min steering angle (right turn)
  double steering_angle_for_rotate_max_;  // Max steering angle (left turn)
  double steering_angle_tolerance_;   // Tolerance của góc lái khi rotate
  double max_trans_vel_for_rotate_;  // Vận tốc bánh transaction khi rotate
  double error_to_low_speed_points_;
  double error_to_special_safety_points_;

  double yaw_goal_tolerance_;
  double xy_goal_tolerance_;
  double init_max_vel_x_;
  double init_vel_x_when_more_angle_;
  double max_vel_requested;
  double init_vel_reduce_after_stop_;

  agv_msgs::ArrayWaypointsResponse array_waypoints_low_speed_;
  agv_msgs::ArraySafetyWaypointsResponse array_waypoints_special_safety_;
};
};  // namespace agf_local_planner
#endif