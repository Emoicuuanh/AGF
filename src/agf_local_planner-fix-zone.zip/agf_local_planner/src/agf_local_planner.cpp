#include <agf_local_planner/agf_local_planner.h>

#include <tf2/utils.h>
#include <tf2_eigen/tf2_eigen.h>

#include <geometry_msgs/PoseStamped.h>

#include <base_local_planner/footprint_helper.h>
#include <base_local_planner/goal_functions.h>
#include <pluginlib/class_list_macros.h>

#include <algorithm>
#include <mbf_msgs/ExePathResult.h>

#include <agv_common_library/get_hardware_hash.h>
#include <math.h>

PLUGINLIB_EXPORT_CLASS(agf_local_planner::AgfLocalPlannerROS,
                       nav_core::BaseLocalPlanner)
PLUGINLIB_EXPORT_CLASS(agf_local_planner::AgfLocalPlannerROS,
                       mbf_costmap_core::CostmapController)

namespace agf_local_planner
{
using json = nlohmann::json;
AgfLocalPlannerROS::AgfLocalPlannerROS()
    : costmap_ros_(NULL), tf_(NULL), costmap_model_(NULL), goal_reached_(false),
      initialized_(false), dynamic_recfg_(NULL)
{
}

AgfLocalPlannerROS::~AgfLocalPlannerROS() {}

void AgfLocalPlannerROS::initialize(std::string name, tf2_ros::Buffer* tf,
                  costmap_2d::Costmap2DROS* costmap_ros)
{
  // License verification (commented out)
  // if (!getUbuntuSerialHash())
  // {
  //   ROS_ERROR("AgfLocalPlanner: License verification failed.");
  //   return;
  // }

  // ============================================================================
  // BASIC INITIALIZATION
  // ============================================================================
  name_ = name;
  ros::NodeHandle private_nh("~/" + name);
  tf_ = tf;
  costmap_ros_ = costmap_ros;
  costmap_ = costmap_ros_->getCostmap();
  global_frame_ = costmap_ros_->getGlobalFrameID();
  robot_base_frame_ = costmap_ros_->getBaseFrameID();

  // ============================================================================
  // LOAD PARAMETERS FROM ROS PARAMETER SERVER
  // ============================================================================

  // Odometry configuration
  odom_topic_ = private_nh.param<std::string>("odom_topic", "/odom");
  odom_helper_.setOdomTopic(odom_topic_);

  // Path following parameters
  distance_to_control_point_ = private_nh.param<double>("distance_to_control_point", 0.7);
  lookahead_dist_ = private_nh.param<double>("lookahead_dist", 0.15);
  look_forward_gain_ = private_nh.param<double>("look_forward_gain", 0.3);

  // Velocity limits
  max_vel_x_ = private_nh.param<double>("max_vel_x", 0.7);
  max_vel_requested = abs(max_vel_x_);
  max_angular_z_ = private_nh.param<double>("max_angular_z", 1.2);
  vel_x_when_more_angle_ = private_nh.param<double>("vel_x_when_more_angle", 0.25);
  init_vel_x_when_more_angle_ = vel_x_when_more_angle_;

  // Control parameters
  weight_acc_ = private_nh.param<double>("weight_acc", 1.5);
  weight_theta_e_ = private_nh.param<double>("weight_theta_e", 0.4);
  weight_theta_d_ = private_nh.param<double>("weight_theta_d", 1.5);
  k_p_ = private_nh.param<double>("k_p", 1.0);

  // Goal tolerance parameters
  error_to_start_stop_ = private_nh.param<double>("error_to_start_stop", 0.3);
  xy_goal_tolerance_ = private_nh.param<double>("xy_goal_tolerance", 0.1);
  yaw_goal_tolerance_ = private_nh.param<double>("yaw_goal_tolerance", 0.1);
  ignore_last_rotate_ = private_nh.param<bool>("ignore_last_rotate", false);

  // Waypoint tolerance parameters
  error_to_low_speed_points_ = private_nh.param<double>("error_to_low_speed_points", 1.5);
  error_to_special_safety_points_ = private_nh.param<double>("error_to_special_safety_points", 0.5);

  // Car-like robot specific parameters
  is_carlike_ = private_nh.param<bool>("is_carlike", true);
  steering_angle_for_rotate_ = private_nh.param<double>("car_like/steering_angle_for_rotate", 1.57);
  steering_angle_for_rotate_min_ = private_nh.param<double>("car_like/steering_angle_for_rotate_min", -steering_angle_for_rotate_);
  steering_angle_for_rotate_max_ = private_nh.param<double>("car_like/steering_angle_for_rotate_max", steering_angle_for_rotate_);
  steering_angle_tolerance_ = private_nh.param<double>("car_like/steering_angle_tolerance", 0.05);
  max_trans_vel_for_rotate_ = private_nh.param<double>("car_like/max_trans_vel_for_rotate", 0.8);

  // Unused/legacy parameters (kept for compatibility)
  angle_to_global_when_start_ = private_nh.param<double>("angle_to_global_when_start", 0.05);
  error_angle_stop_ = private_nh.param<double>("error_angle_stop", 0.1);
  max_error_pose_to_path_ = private_nh.param<double>("max_error_pose_to_path", 0.2);

  // State flags
  rotate_to_goal_ = private_nh.param<bool>("rotate_to_goal", false);
  allow_set_safety_ = true;
  priority_angle_adjustment_ = false;

  // ============================================================================
  // SETUP PUBLISHERS
  // ============================================================================
  pub_path_ = nh_.advertise<nav_msgs::Path>("/move_base/GlobalPlanner/plan", 1);
  pub_safety_control_ = nh_.advertise<agf_msgs::Int8Array>("/safety_control", 1);

  // Visualization publishers for debugging path following
  pub_local_path_ = nh_.advertise<nav_msgs::Path>("/agf_local_planner/local_path", 1);
  pub_lookahead_point_ = nh_.advertise<visualization_msgs::Marker>("/agf_local_planner/lookahead_point", 1);
  pub_nearest_point_ = nh_.advertise<visualization_msgs::Marker>("/agf_local_planner/nearest_point", 1);
  pub_control_point_ = nh_.advertise<visualization_msgs::Marker>("/agf_local_planner/control_point", 1);

  // ============================================================================
  // SETUP SUBSCRIBERS
  // ============================================================================
  sub_cmd_vel_ = nh_.subscribe("/cmd_vel_feedback", 1, &AgfLocalPlannerROS::cmdVelCallback, this);
  // sub_safety_zone_ = nh_.subscribe("/safety_status", 1, &AgfLocalPlannerROS::safetyCallback, this);
  sub_angle_steer_ = nh_.subscribe("/steering_angle", 1, &AgfLocalPlannerROS::steeringAngleCallback, this);
  request_speed_limit_sub = nh_.subscribe("set_safety/request_zone_speed_limit", 1, &AgfLocalPlannerROS::request_speed_limit_cb, this);

  request_safety_job_sub = nh_.subscribe("set_safety/request_zone_safety_job", 1,
                                 &AgfLocalPlannerROS::request_safety_job_cb, this);

  // ============================================================================
  // SETUP SERVICE CLIENTS
  // ============================================================================
  client_get_waypoints_low_speed_ = nh_.serviceClient<agv_msgs::ArrayWaypoints>("/waypoints_low_speed");
  client_get_waypoints_special_safety_ = nh_.serviceClient<agv_msgs::ArraySafetyWaypoints>("/waypoints_special_safety");

  // ============================================================================
  // SETUP DYNAMIC RECONFIGURE
  // ============================================================================
  dynamic_recfg_ = boost::make_shared<dynamic_reconfigure::Server<AgfLocalPlannerReconfigureConfig>>(private_nh);
  dynamic_reconfigure::Server<AgfLocalPlannerReconfigureConfig>::CallbackType cb =
    boost::bind(&AgfLocalPlannerROS::reconfigureCB, this, _1, _2);
  dynamic_recfg_->setCallback(cb);

  // ============================================================================
  // FINAL INITIALIZATION
  // ============================================================================
  msg_safety_.ints.resize(4);
  msg_safety_zone_.ints.resize(4);
  // Default safety zones: all directions safe
  resetSafetyZone();
  old_time_ = ros::Time::now().toSec();

  std::cout << "vel_x_when_more_angle: " << vel_x_when_more_angle_ << std::endl;

  initialized_ = true;
}

void AgfLocalPlannerROS::reconfigureCB(AgfLocalPlannerReconfigureConfig& config,
                                       uint32_t level)
{
  if (!initialized_)
  {
    return;
  }
  allow_set_safety_ = config.allow_set_safety;
  priority_angle_adjustment_ = config.priority_angle_adjustment;
  ROS_ERROR("Set allow_set_safety: %d", allow_set_safety_);
  ROS_ERROR("Set priority_angle_adjustment: %d", priority_angle_adjustment_);
}

void AgfLocalPlannerROS::cmdVelCallback(
    const geometry_msgs::Twist::ConstPtr msg)
{
  robot_vel_ = *msg;
}

void AgfLocalPlannerROS::steeringAngleCallback(
    const std_msgs::Float64::ConstPtr msg)
{
  steering_angle_ = msg->data;
}

// void AgfLocalPlannerROS::safetyCallback(
//     const safety_msgs::SafetyStatus::ConstPtr msg)
// {
//   have_safety_ = true;
//   field_safety_ = *msg;
//   setRuleSafety();
// }

void AgfLocalPlannerROS::request_speed_limit_cb(
  std_stamped_msgs::StringStamped::ConstPtr msg)
{
  try {
    // Parse simple float value from string
    max_vel_requested = abs(std::stod(msg->data));
    ROS_INFO_ONCE("Set max_vel_x: %.2f m/s", max_vel_requested);
  }
  catch (const std::exception& e) {
    ROS_ERROR_ONCE("Failed to parse speed limit: %s", e.what());
    max_vel_requested = abs(max_vel_x_);
    ROS_WARN_ONCE("Max_vel set to default: %f", max_vel_requested);
  }
}

void AgfLocalPlannerROS::request_safety_job_cb(agf_msgs::Int8Array::ConstPtr msg)
{
  // Store the received safety array [f1, f2, f3, f4]
  if (msg->ints.size() >= 4)
  {
    // set_safety publishes every cycle (15 Hz), only log when the zone safety changes
    const bool changed = msg_safety_zone_.ints[0] != msg->ints[0] || msg_safety_zone_.ints[1] != msg->ints[1] ||
                         msg_safety_zone_.ints[2] != msg->ints[2] || msg_safety_zone_.ints[3] != msg->ints[3];
    msg_safety_zone_.ints[0] = msg->ints[0];
    msg_safety_zone_.ints[1] = msg->ints[1];
    msg_safety_zone_.ints[2] = msg->ints[2];
    msg_safety_zone_.ints[3] = msg->ints[3];
    if (changed)
      ROS_WARN("Update safety by zone: [%d, %d, %d, %d]",
               msg_safety_zone_.ints[0], msg_safety_zone_.ints[1],
               msg_safety_zone_.ints[2], msg_safety_zone_.ints[3]);
  }
  else
  {
    ROS_WARN_ONCE("Received safety array has less than 4 elements");
  }
}

// void AgfLocalPlannerROS::setRuleSafety()
// {
//   // rule_safety_ = 99;
//   // for (auto i = 0; i < field_safety_.fields.size(); i++)
//   // {
//   //   if (field_safety_.fields[i] == 1)
//   //   {
//   //     rule_safety_ = i;
//   //     return;
//   //   }
//   // }
// }

bool AgfLocalPlannerROS::setPlan(
    const std::vector<geometry_msgs::PoseStamped>& orig_global_plan)
{
  ROS_INFO("-----Local planner: begin set plan-----");
  if (!initialized_)
  {
    ROS_ERROR("This planner has not been initialized, please call initialize() "
              "before using this planner");
    return false;
  }

  global_plan_.clear();
  global_goal_ = orig_global_plan.back();
  global_plan_ = orig_global_plan;

  // Get status robot go forward or backward
  if (global_plan_.front().pose.orientation.x == 1)
  {
    go_forward_ = false;
  }
  else
  {
    go_forward_ = true;
  }

  // get waypoints low speed
  array_waypoints_low_speed_.Waypoints.clear();
  agv_msgs::ArrayWaypoints srv;
  client_get_waypoints_low_speed_.call(srv);
  array_waypoints_low_speed_ = srv.response;

  // get waypoints special safety
  array_waypoints_special_safety_.Waypoints.clear();
  agv_msgs::ArraySafetyWaypoints srv1;
  client_get_waypoints_special_safety_.call(srv1);
  array_waypoints_special_safety_ = srv1.response;

  // Reset state
  goal_reached_ = false;
  is_near_goal_ = false;
  rotate_to_goal_ = false;
  correcting_position_after_rotate_ = false;
  low_speed_ = false;

  safety_job_ = -1;
  resetSafetyZone();
  // Zone speed limit is re-sent by set_safety while robot is inside a zone
  max_vel_requested = abs(max_vel_x_);
  robot_vel_.linear.x = 0.0;

  old_time_ = ros::Time::now().toSec();

  // Publish global path
  path_global_.header.stamp = ros::Time::now();
  path_global_.header.frame_id = "map";
  path_global_.poses = orig_global_plan;
  pub_path_.publish(path_global_);
  ROS_INFO("Local planner: set plan done");
  return true;
}

// Safety base on point will rewrite safety based on zone
void AgfLocalPlannerROS::setSafety(double distance_to_goal)
{
  // Fill from zone request (or defaults) first, so cases that do not set
  // msg_safety_ never publish stale / zero values.
  const bool zone_unset = msg_safety_zone_.ints[0] == -1 && msg_safety_zone_.ints[1] == -1 &&
                          msg_safety_zone_.ints[2] == -1 && msg_safety_zone_.ints[3] == -1;
  if (zone_unset)
  {
    if (go_forward_)
      msg_safety_.ints = {6, 1, 1, 1};
    else
      msg_safety_.ints = {1, 1, 1, 5};
  }
  else
  {
    msg_safety_.ints = msg_safety_zone_.ints;
  }

  if (go_forward_)  // if(false)
  {
    switch (safety_job_) {
      case 0:
        // msg_safety_.ints[0] = 1;
        // msg_safety_.ints[1] = 1;
        // msg_safety_.ints[2] = 1;
        // msg_safety_.ints[3] = 1;
        break;

      case 1:
        // msg_safety_.ints[0] = 3;
        // msg_safety_.ints[1] = 3;
        // msg_safety_.ints[2] = 3;
        // msg_safety_.ints[3] = 3;
        break;

      case 2:
        // msg_safety_.ints[0] = 5;
        // msg_safety_.ints[1] = 5;
        // msg_safety_.ints[2] = 5;
        // msg_safety_.ints[3] = 5;
        break;

      case 3:
        // msg_safety_.ints[0] = 2;
        // msg_safety_.ints[1] = 7;
        // msg_safety_.ints[2] = 7;
        // msg_safety_.ints[3] = 11;
        break;
      case 4:
        msg_safety_.ints[0] = 4;
        msg_safety_.ints[1] = 8;
        msg_safety_.ints[2] = 8;
        msg_safety_.ints[3] = 11;
        break;
      // ZONE-BASED SAFETY MODE (default): Use safety values from zone topic
      // Forward motion: direct mapping [front, left, right, rear]
      default:
        if (msg_safety_zone_.ints[0] == -1
          && msg_safety_zone_.ints[1] == -1
          && msg_safety_zone_.ints[2] == -1
          && msg_safety_zone_.ints[3] == -1 )
        {
          msg_safety_.ints[0] = 6;  // front
          msg_safety_.ints[1] = 1;  // left
          msg_safety_.ints[2] = 1;  // right
          msg_safety_.ints[3] = 1;  // rear
          break;
        }
        msg_safety_.ints[0] = msg_safety_zone_.ints[0];  // front
        msg_safety_.ints[1] = msg_safety_zone_.ints[1];  // left
        msg_safety_.ints[2] = msg_safety_zone_.ints[2];  // right
        msg_safety_.ints[3] = msg_safety_zone_.ints[3];  // rear
        break;
    }
  }
  else{
    switch (safety_job_) {
      case 0:
        // msg_safety_.ints[0] = 2;
        // msg_safety_.ints[1] = 2;
        // msg_safety_.ints[2] = 2;
        // msg_safety_.ints[3] = 2;
        break;

      case 1:
        // msg_safety_.ints[0] = 4;
        // msg_safety_.ints[1] = 4;
        // msg_safety_.ints[2] = 4;
        // msg_safety_.ints[3] = 4;
        break;

      case 2:
        // msg_safety_.ints[0] = 6;
        // msg_safety_.ints[1] = 6;
        // msg_safety_.ints[2] = 6;
        // msg_safety_.ints[3] = 6;
        break;

      // RANGE BASE SAFETY MODE: Adjust safety levels based on distance to goal
      case 3:
        if (abs(distance_to_goal) < 1.1)
        {
          msg_safety_.ints[0] = 5;
          msg_safety_.ints[1] = 2;
          msg_safety_.ints[2] = 2;
          msg_safety_.ints[3] = 11;
          break;
        }
        else if (abs(distance_to_goal) < 1.3)
        {
          msg_safety_.ints[0] = 5;
          msg_safety_.ints[1] = 2;
          msg_safety_.ints[2] = 2;
          msg_safety_.ints[3] = 10;
          break;
        }
        else if (abs(distance_to_goal) < 1.5)
        {
          msg_safety_.ints[0] = 5;
          msg_safety_.ints[1] = 2;
          msg_safety_.ints[2] = 2;
          msg_safety_.ints[3] = 9;
          break;
        }
        else
        {
          msg_safety_.ints[0] = 5;
          msg_safety_.ints[1] = 2;
          msg_safety_.ints[2] = 2;
          msg_safety_.ints[3] = 8;
          break;
        }
      //disable safety fork when near zone
      case 4:
        if (abs(distance_to_goal) < 1.1)
        {
          msg_safety_.ints[0] = 6;
          msg_safety_.ints[1] = 8;
          msg_safety_.ints[2] = 8;
          msg_safety_.ints[3] = 6;
          break;
        }
        else if (abs(distance_to_goal) < 1.3)
        {
          msg_safety_.ints[0] = 4;
          msg_safety_.ints[1] = 4;
          msg_safety_.ints[2] = 4;
          msg_safety_.ints[3] = 6;
          break;
        }
        else if (abs(distance_to_goal) < 1.5)
        {
          msg_safety_.ints[0] = 4;
          msg_safety_.ints[1] = 4;
          msg_safety_.ints[2] = 4;
          msg_safety_.ints[3] = 9;
          break;
        }
        else
        {
          msg_safety_.ints[0] = 4;
          msg_safety_.ints[1] = 4;
          msg_safety_.ints[2] = 4;
          msg_safety_.ints[3] = 8;
          break;
        }
      // ZONE-BASED SAFETY MODE (default): Use safety values from zone topic
      // Backward motion: reverse front↔rear since rear sensors now lead
      default:
        if (msg_safety_zone_.ints[0] == -1
          && msg_safety_zone_.ints[1] == -1
          && msg_safety_zone_.ints[2] == -1
          && msg_safety_zone_.ints[3] == -1 )
        {
          msg_safety_.ints[0] = 1;  // front
          msg_safety_.ints[1] = 1;  // left
          msg_safety_.ints[2] = 1;  // right
          msg_safety_.ints[3] = 5;  // rear
          break;
        }
        msg_safety_.ints[0] = msg_safety_zone_.ints[0];  // rear becomes front
        msg_safety_.ints[1] = msg_safety_zone_.ints[1];  // left stays left
        msg_safety_.ints[2] = msg_safety_zone_.ints[2];  // right stays right
        msg_safety_.ints[3] = msg_safety_zone_.ints[3];  // front becomes rear
        break;
    }
  }
  // Zone request is kept until set_safety sends a new one (it publishes
  // [-1,-1,-1,-1] when out of zone); it is reset in setPlan for a new goal.
  pub_safety_control_.publish(msg_safety_);
}

bool AgfLocalPlannerROS::checkRobotNearSlowPoint(
    const geometry_msgs::PoseStamped& pose_robot)
{
  if (array_waypoints_low_speed_.Waypoints.size() == 0)
  {
    return false;
  }

  for (auto i = 0; i < array_waypoints_low_speed_.Waypoints.size(); i++)
  {
    double dx = array_waypoints_low_speed_.Waypoints[i].pose.position.x -
                pose_robot.pose.position.x;
    double dy = array_waypoints_low_speed_.Waypoints[i].pose.position.y -
                pose_robot.pose.position.y;
    double distance = sqrt(dx * dx + dy * dy);
    if (distance < error_to_low_speed_points_)
    {
      return true;
    }
  }

  return false;
}

int AgfLocalPlannerROS::checkRobotNearSpecialSafety(
    const geometry_msgs::PoseStamped& pose_robot)
{
  if (array_waypoints_special_safety_.Waypoints.size() == 0)
  {
    return -1;
  }

  int size_wps = array_waypoints_special_safety_.Waypoints.size();
  for (auto i = 1; i <= size_wps; i++)
  {
    double dx = array_waypoints_special_safety_.Waypoints[size_wps - i].Pose.pose.position.x -
                pose_robot.pose.position.x;
    double dy = array_waypoints_special_safety_.Waypoints[size_wps - i].Pose.pose.position.y -
                pose_robot.pose.position.y;
    double distance = sqrt(dx * dx + dy * dy);
    if (distance < error_to_special_safety_points_)
    {
      return array_waypoints_special_safety_.Waypoints[size_wps - i].safety_job;
    }
  }

  return -1;
}

bool AgfLocalPlannerROS::computeVelocityCommands(geometry_msgs::Twist& cmd_vel)
{
  std::string dummy_message;
  geometry_msgs::PoseStamped dummy_pose;
  geometry_msgs::TwistStamped dummy_velocity, cmd_vel_stamped;
  uint32_t outcome = computeVelocityCommands(dummy_pose, dummy_velocity,
                                             cmd_vel_stamped, dummy_message);
  cmd_vel = cmd_vel_stamped.twist;
  // return true if outcome = 0
  return outcome == mbf_msgs::ExePathResult::SUCCESS;
}

uint32_t AgfLocalPlannerROS::computeVelocityCommands(
    const geometry_msgs::PoseStamped& pose,
    const geometry_msgs::TwistStamped& velocity,
    geometry_msgs::TwistStamped& cmd_vel, std::string& message)
{
  // Get dt
  new_time_ = ros::Time::now().toSec();
  dt_ = new_time_ - old_time_;
  old_time_ = new_time_;

  static uint32_t seq = 0;
  cmd_vel.header.seq = seq++;
  cmd_vel.header.stamp = ros::Time::now();
  cmd_vel.header.frame_id = robot_base_frame_;
  cmd_vel.twist.linear.x = cmd_vel.twist.linear.y = cmd_vel.twist.angular.z = 0;
  goal_reached_ = false;

  // Get robot pose
  geometry_msgs::PoseStamped robot_pose;
  costmap_ros_->getRobotPose(robot_pose);

  //check near pose slow speed
  low_speed_ = checkRobotNearSlowPoint(robot_pose);

  double error_goal_x =
      global_goal_.pose.position.x - robot_pose.pose.position.x;
  double error_goal_y =
      global_goal_.pose.position.y - robot_pose.pose.position.y;
  double distance_to_goal =
      sqrt(error_goal_x * error_goal_x + error_goal_y * error_goal_y);

  if (allow_set_safety_)
  {
    int current_safety_job = checkRobotNearSpecialSafety(robot_pose);
    if (current_safety_job != -1)
      safety_job_ = current_safety_job;
    std::cout << "error_to_special_safety_points: " << error_to_special_safety_points_ << std::endl;
    std::cout << "safety_job: " << safety_job_ << std::endl;
    std::cout << "distance_to_goal: " << distance_to_goal << std::endl;
    setSafety(distance_to_goal);
  }

  // Get velocity of robot
  ros::spinOnce();

  // Get yaw of robot
  double yaw_robot = quaternionToRPY(
      robot_pose.pose.orientation.x, robot_pose.pose.orientation.y,
      robot_pose.pose.orientation.z, robot_pose.pose.orientation.w);

  double distance_control, lookahead_dist;
  // ROS_ERROR("%f", cos(steering_angle_));
  if (go_forward_)
  {
    // - distance_to_control_point_: nếu diff thì = 0, nếu carlike thì tuning
    // sao cho bám theo base_link, theo lý thuyết thì bằng wheel_base nhưng thực
    // tế nếu bằng wheel_base thì sẽ không bám theo base_link
    distance_control = distance_to_control_point_;
    // - lookahead_dist_: nếu cua bám đường k tốt thì giảm xuống nhưng nếu nhỏ
    // quá đi thẳng sẽ bị lắc
    // - look_forward_gain_: nếu đi thẳng mà bị lắc thì tăng lên
    // - robot_vel_: là vận tốc điều khiển cuối cùng vào động cơ, dùng để tính
    // vận tốc tiếp theo theo gia tốc và dt, nếu lấy theo odom thì odom chậm nên
    // khi tính vận tốc tiếp theo sẽ bị sai. Tại sao không lấy biến cmd_vel vận
    // tốc hiện tại trong chương trình luôn?
    lookahead_dist = lookahead_dist_ + robot_vel_.linear.x *
                                           look_forward_gain_ *
                                           cos(steering_angle_);
  }
  else
  {
    distance_control = -distance_to_control_point_;
    lookahead_dist = lookahead_dist_ - robot_vel_.linear.x *
                                           look_forward_gain_ *
                                           cos(steering_angle_);
  }

  // Find pose control
  geometry_msgs::PoseStamped pose_control;
  pose_control.pose.position.x =
      robot_pose.pose.position.x + cos(yaw_robot) * distance_control;
  pose_control.pose.position.y =
      robot_pose.pose.position.y + sin(yaw_robot) * distance_control;
  pose_control.pose.orientation.z = robot_pose.pose.orientation.z;
  pose_control.pose.orientation.w = robot_pose.pose.orientation.w;

  // Control robot
  if (rotate_to_goal_ == false)
  {
    bool success = control(pose_control, lookahead_dist, cmd_vel, robot_pose);
  }
  else
  {
    double yaw_goal = quaternionToRPY(
        global_goal_.pose.orientation.x, global_goal_.pose.orientation.y,
        global_goal_.pose.orientation.z, global_goal_.pose.orientation.w);
    double diff_angle = normalizeAngle(yaw_goal - yaw_robot);
    // ROS_INFO("diff_angle: %f", diff_angle);

    if (is_carlike_)
    {
      if (rotateCarLike(cmd_vel, robot_pose, diff_angle))
      {
        // Rotation completed, now check if position is still within tolerance
        // Calculate position error after rotation
        double error_goal_x = global_goal_.pose.position.x - robot_pose.pose.position.x;
        double error_goal_y = global_goal_.pose.position.y - robot_pose.pose.position.y;
        double position_error = sqrt(error_goal_x * error_goal_x + error_goal_y * error_goal_y);

        if (position_error > xy_goal_tolerance_)
        {
          // Position drifted during rotation, need to correct it
          ROS_WARN("Position error after rotation: %.3f m (tolerance: %.3f m). Correcting position...",
                   position_error, xy_goal_tolerance_);

          // Reset flags to go back to position correction mode
          rotate_to_goal_ = false;
          is_near_goal_ = false;
          goal_reached_ = false;
          correcting_position_after_rotate_ = true;  // Mark that we're correcting position

          // Don't return SUCCESS yet, continue with position correction
          // The control() function will be called next iteration to fix position
        }
        else
        {
          // Both angle and position are within tolerance
          ROS_INFO("Goal reached! Position error: %.3f m, Angle error: %.3f rad",
                   position_error, diff_angle);
          goal_reached_ = true;
          correcting_position_after_rotate_ = false;
          return mbf_msgs::ExePathResult::SUCCESS;
        }
      }
    }
    else
    {
      if (diff_angle < yaw_goal_tolerance_)
      {
        cmd_vel.twist.linear.x = 0;
        cmd_vel.twist.angular.z = 0;
        goal_reached_ = true;
        return mbf_msgs::ExePathResult::SUCCESS;
      }
      double angular_z = 0.8 * diff_angle;
      angular_z = std::min(angular_z, max_angular_z_);
      angular_z = std::max(angular_z, -max_angular_z_);
      cmd_vel.twist.linear.x = 0;
      cmd_vel.twist.angular.z = angular_z;
    }
  }
  // Nếu không return SUCCESS trong hàm này thì cả 2 planner bị gọi lại liên tục
  return mbf_msgs::ExePathResult::SUCCESS;
}

bool AgfLocalPlannerROS::rotateCarLike(
    geometry_msgs::TwistStamped& cmd_vel,
    const geometry_msgs::PoseStamped& robot_pose, double diff_angle)
{
  static int state = 0, prev_state = -1, dir = 0;
  static double target_steering = 0.0;
  static double last_time = ros::Time::now().toSec();
  static double new_time = last_time;
  new_time = ros::Time::now().toSec();
  // Auto reset state after 1 second for next action
  if (new_time - last_time > 1.0)
  {
    state = 0;
    prev_state = -1;
  }
  last_time = new_time;

  if (state != prev_state)
  {
    if (state == 0)
    {
      ROS_INFO("---Begin rotate car like---");
    }
    else
    {
      ROS_INFO("Rotate carlike state: %d => %d", prev_state, state);
    }
    prev_state = state;
  }

  // Calculate steering and direction ONLY when starting rotation (state 0)
  // This prevents oscillation as diff_angle changes during rotation
  if (state == 0)
  {
    // Select steering angle based on yaw error direction
    // REAR STEERING: steering direction is inverted
    // Positive diff_angle (turn left) -> use min (negative), Negative (turn right) -> use max (positive)
    target_steering = (diff_angle >= 0.0) ? steering_angle_for_rotate_min_
                                          : steering_angle_for_rotate_max_;

    // Calculate position error: are we behind or past the goal?
    double dx = global_goal_.pose.position.x - robot_pose.pose.position.x;
    double dy = global_goal_.pose.position.y - robot_pose.pose.position.y;
    double yaw_robot = quaternionToRPY(
        robot_pose.pose.orientation.x, robot_pose.pose.orientation.y,
        robot_pose.pose.orientation.z, robot_pose.pose.orientation.w);

    // Project position error onto robot's forward direction
    double forward_error = dx * cos(yaw_robot) + dy * sin(yaw_robot);

    // If positive: goal is ahead (roll forward), if negative: goal is behind (roll backward)
    dir = (forward_error >= 0.0) ? 1 : -1;

    ROS_INFO("Rotate CarLike START: diff_angle=%.3f rad (%.1f deg), Turn %s, target_steering=%.3f rad (%.1f deg), forward_error=%.3f m, dir=%s",
                      diff_angle, diff_angle * 180.0 / M_PI,
                      (diff_angle >= 0.0) ? "LEFT" : "RIGHT",
                      target_steering, target_steering * 180.0 / M_PI,
                      forward_error, (dir > 0) ? "FORWARD" : "BACKWARD");
  }

  ROS_INFO_THROTTLE(0.5, "Rotate CarLike state=%d: diff_angle=%.3f rad (%.1f deg), using target_steering=%.3f rad, dir=%s",
                    state, diff_angle, diff_angle * 180.0 / M_PI,
                    target_steering, (dir > 0) ? "FORWARD" : "BACKWARD");

  switch (state)
  {
  case 0:  // ROTATE_STEERING
    cmd_vel.twist.linear.x = 0.0;
    cmd_vel.twist.angular.z = target_steering;
    if (abs(steering_angle_ - target_steering) <
        steering_angle_tolerance_)
    {
      state = 1;
    }
    break;
  case 1:  // DELAY_AF_ROTATE
    state = 2;
    break;
  case 2:  // ROLLING_MAIN_WHEEL
    cmd_vel.twist.angular.z = target_steering;
    cmd_vel.twist.linear.x = std::min(max_trans_vel_for_rotate_,
                                      max_trans_vel_for_rotate_) * dir;

    if (abs(diff_angle) < yaw_goal_tolerance_)
    {
      cmd_vel.twist.linear.x = 0.0;
      state = 3;
    }
    break;
  case 3:  // DELAY_AF_ROLLING
    state = 4;
    break;
  case 4:  // RETURN_STEERING
    cmd_vel.twist.angular.z = 0.0;
    if (abs(steering_angle_) < steering_angle_tolerance_)
    {
      state = 5;
    }
    break;
  case 5:  // DELAY_AF_STEERING
    state = 0;
    return true;
    break;

  default:
    break;
  }
  // ROS_INFO("linear.x: %f, angular.z: %f", cmd_vel.twist.linear.x,
  //          cmd_vel.twist.angular.z);
  return false;
}

/**
 * @brief Controls robot movement using a path following algorithm with lookahead control
 *
 * This function implements a control algorithm that computes velocity commands for the robot
 * to follow a global path. It uses a lookahead-based approach with error correction and
 * adaptive velocity control based on path curvature and distance to goal.
 *
 * @param pose_control Current pose of the robot control point
 * @param lookahead_dist Distance ahead on the path to use for lookahead control
 * @param cmd_vel Output velocity command (linear and angular velocities)
 * @param robot_pose Current pose of the robot
 *
 * @return true if control computation is successful, false otherwise
 *
 * @details The control algorithm performs the following steps:
 * - Finds the nearest point on the global path to the current robot position
 * - Computes distance to the goal and determines if near goal behavior should be used
 * - Trims the global path by removing points behind the robot
 * - Finds the lookahead point on the path at the specified lookahead distance
 * - Calculates two error terms:
 *   - theta_e: angle error to the lookahead point
 *   - theta_d: lateral distance error to the path
 * - Combines errors using weighted sum to compute steering command
 * - Implements adaptive velocity control:
 *   - Reduces speed for sharp turns (high angular error)
 *   - Uses proportional control for goal approach when near the target
 *   - Applies acceleration limits and velocity constraints
 * - Supports both forward and backward motion modes
 * - Handles special cases like goal tolerance checking and final rotation to goal
 *
 * @note The function modifies the global_plan_ by removing waypoints behind the robot
 * @note Uses member variables for PID gains, velocity limits, and other control parameters
 * @note Sets internal flags like is_near_goal_, goal_reached_, and rotate_to_goal_
 */
bool AgfLocalPlannerROS::control(const geometry_msgs::PoseStamped& pose_control,
                                 double lookahead_dist,
                                 geometry_msgs::TwistStamped& cmd_vel,
                                 const geometry_msgs::PoseStamped& robot_pose)
{
  // ============================================================================
  // STEP 1: INITIALIZE VARIABLES
  // ============================================================================
  // Output velocity commands to be calculated
  double vel_x, angular_z;

  // Get the yaw angle (heading) of the control point from its quaternion orientation
  double yaw_pose_control = quaternionToRPY(
      pose_control.pose.orientation.x, pose_control.pose.orientation.y,
      pose_control.pose.orientation.z, pose_control.pose.orientation.w);

  // Acceleration for velocity smoothing (set velocity changes gradually)
  double acc_vel_x = 0;

  // Control error terms:
  // - delta: combined steering command (weighted sum of theta_e and theta_d)
  // - theta_e: heading error (angle between robot heading and desired direction to lookahead point)
  // - theta_d: cross-track error (lateral distance from robot to path, converted to angle)
  // - error_front_axle: perpendicular distance from control point to path
  // - limit_vel: velocity limit based on current situation (curves, near goal, etc.)
  double delta, theta_e, theta_d, error_front_axle, limit_vel;

  // ============================================================================
  // STEP 2: FIND NEAREST POINT ON PATH TO CONTROL POINT
  // ============================================================================
  // This finds the closest point on the global path to the robot's control point
  // The control point is offset from base_link by distance_to_control_point_ in the heading direction
  geometry_msgs::PoseStamped pose_nearest_robot;
  int number_nearest_pose;
  findPointInPath(pose_control, global_plan_, pose_nearest_robot, 0.0,
                  number_nearest_pose);

  // ============================================================================
  // STEP 3: CALCULATE DISTANCE TO GOAL
  // ============================================================================
  // Calculate remaining distance from nearest path point to final goal
  // This is used to determine when to start slowing down (approaching goal)
  double error_goal_x =
      global_goal_.pose.position.x - pose_nearest_robot.pose.position.x;
  double error_goal_y =
      global_goal_.pose.position.y - pose_nearest_robot.pose.position.y;
  double distance_to_goal =
        sqrt(error_goal_x * error_goal_x + error_goal_y * error_goal_y);

  // ============================================================================
  // STEP 4: PRUNE PATH (REMOVE POINTS BEHIND ROBOT)
  // ============================================================================
  // Remove all path points before the nearest point to prevent robot from trying to go backwards
  // This effectively "consumes" the path as the robot moves along it
  if (global_plan_.size() > 3)
  {
    global_plan_.erase(global_plan_.begin(),
                       global_plan_.begin() + number_nearest_pose);
  }

  // ============================================================================
  // STEP 5: FIND LOOKAHEAD POINT FOR PURE PURSUIT
  // ============================================================================
  // The lookahead point is ahead of the robot on the path by lookahead_dist
  // This is the target point the robot tries to steer towards (Pure Pursuit algorithm)
  geometry_msgs::PoseStamped lookahead_pose;
  int number_lookahead_pose;
  findPointInPath(pose_control, global_plan_, lookahead_pose, lookahead_dist,
                  number_lookahead_pose);

  // ============================================================================
  // VISUALIZATION: PUBLISH PATH AND KEY POINTS
  // ============================================================================
  // Publish pruned local path (what robot is currently following)
  nav_msgs::Path local_path_msg;
  local_path_msg.header.stamp = ros::Time::now();
  local_path_msg.header.frame_id = global_frame_;
  local_path_msg.poses = global_plan_;
  pub_local_path_.publish(local_path_msg);

  // Publish control point marker (green sphere)
  visualization_msgs::Marker control_marker;
  control_marker.header.stamp = ros::Time::now();
  control_marker.header.frame_id = global_frame_;
  control_marker.ns = "control_point";
  control_marker.id = 0;
  control_marker.type = visualization_msgs::Marker::SPHERE;
  control_marker.action = visualization_msgs::Marker::ADD;
  control_marker.pose = pose_control.pose;
  control_marker.scale.x = 0.15;
  control_marker.scale.y = 0.15;
  control_marker.scale.z = 0.15;
  control_marker.color.r = 0.0;
  control_marker.color.g = 1.0;
  control_marker.color.b = 0.0;
  control_marker.color.a = 1.0;
  pub_control_point_.publish(control_marker);

  // Publish nearest point marker (blue sphere)
  visualization_msgs::Marker nearest_marker;
  nearest_marker.header.stamp = ros::Time::now();
  nearest_marker.header.frame_id = global_frame_;
  nearest_marker.ns = "nearest_point";
  nearest_marker.id = 1;
  nearest_marker.type = visualization_msgs::Marker::SPHERE;
  nearest_marker.action = visualization_msgs::Marker::ADD;
  nearest_marker.pose = pose_nearest_robot.pose;
  nearest_marker.scale.x = 0.15;
  nearest_marker.scale.y = 0.15;
  nearest_marker.scale.z = 0.15;
  nearest_marker.color.r = 0.0;
  nearest_marker.color.g = 0.0;
  nearest_marker.color.b = 1.0;
  nearest_marker.color.a = 1.0;
  pub_nearest_point_.publish(nearest_marker);

  // Publish lookahead point marker (red sphere)
  visualization_msgs::Marker lookahead_marker;
  lookahead_marker.header.stamp = ros::Time::now();
  lookahead_marker.header.frame_id = global_frame_;
  lookahead_marker.ns = "lookahead_point";
  lookahead_marker.id = 2;
  lookahead_marker.type = visualization_msgs::Marker::SPHERE;
  lookahead_marker.action = visualization_msgs::Marker::ADD;
  lookahead_marker.pose = lookahead_pose.pose;
  lookahead_marker.scale.x = 0.2;
  lookahead_marker.scale.y = 0.2;
  lookahead_marker.scale.z = 0.2;
  lookahead_marker.color.r = 1.0;
  lookahead_marker.color.g = 0.0;
  lookahead_marker.color.b = 0.0;
  lookahead_marker.color.a = 1.0;
  pub_lookahead_point_.publish(lookahead_marker);

  // ============================================================================
  // STEP 6: CALCULATE HEADING ERROR (theta_e)
  // ============================================================================
  // theta_e is the angular difference between the robot's current heading
  // and the direction to the lookahead point
  // This error term makes the robot point towards the lookahead target

  // This error term makes the robot point towards the lookahead target
  if (go_forward_)
  {
    // FORWARD MODE: Calculate angle from control point to lookahead point
    theta_e =
        atan2((lookahead_pose.pose.position.y - pose_control.pose.position.y),
              (lookahead_pose.pose.position.x - pose_control.pose.position.x)) -
        yaw_pose_control;
  }
  else
  {
    // BACKWARD MODE: Robot is moving in reverse
    if(!priority_angle_adjustment_)
    {
      // Standard backward mode: reverse the direction calculation
      theta_e =
          atan2((pose_control.pose.position.y - lookahead_pose.pose.position.y),
                (pose_control.pose.position.x - lookahead_pose.pose.position.x)) -
          yaw_pose_control;
    }
    else
    {
      // Priority angle adjustment mode: special handling for precise backward maneuvers
      // Uses the path direction (from lookahead to nearest) instead of lookahead direction
      if (pose_nearest_robot.pose.position.x != lookahead_pose.pose.position.x ||
          pose_nearest_robot.pose.position.y != lookahead_pose.pose.position.y)
      {
        // Calculate angle based on path direction vector
        theta_e =
            atan2((pose_nearest_robot.pose.position.y - lookahead_pose.pose.position.y),
                  (pose_nearest_robot.pose.position.x - lookahead_pose.pose.position.x)) -
            yaw_pose_control;

        // Amplify angle error when very close to goal (< 0.65m) for precise final approach
        if (distance_to_goal < 0.65)
        {
          theta_e = 8 * theta_e;
        }
      }
      else
      {
        // Lookahead and nearest points coincide (path segment too short)
        theta_e = 0.0;
      }
    }
  }

  // Normalize theta_e to [-π, π] range
  theta_e = normalizeAngle(theta_e);

  // ============================================================================
  // STEP 7: CALCULATE CROSS-TRACK ERROR (theta_d)
  // ============================================================================
  // theta_d represents the perpendicular distance from the control point to the path
  // This error term helps the robot stay on the path rather than just pointing at the lookahead
  //
  // GEOMETRIC VISUALIZATION:
  //
  //                      PATH DIRECTION →
  //
  //                         Point[2] ●
  //                                ↗
  //                              ↗  a1 (path direction vector)
  //                            ↗
  //         Control Point    ↗
  //              ●         ↗
  //               ╲      ↗
  //            a2  ╲   ↗
  //    (error vec)  ╲↗
  //                 ●
  //           Point[0] (nearest)
  //
  // CROSS PRODUCT SIGN CONVENTION:
  //   Xprod = a1 × a2 = (a11 * a22) - (a12 * a21)
  //
  //   If Xprod > 0:  Control point is on LEFT side of path
  //                  ●─────→ path
  //                  ↑
  //                  robot (left side)
  //
  //   If Xprod < 0:  Control point is on RIGHT side of path
  //                  ●─────→ path
  //                  ↓
  //                  robot (right side)
  //
  //   If Xprod = 0:  Control point is exactly on the path line
  //
  // FORMULA BREAKDOWN:
  //   a1 = [a11, a12] = Point[2] - Point[0]     (path direction)
  //   a2 = [a21, a22] = ControlPoint - Point[0] (position error)
  //
  //   Cross Product (2D): Xprod = a1.x * a2.y - a1.y * a2.x
  //                      = a11 * a22 - a12 * a21
  //
  //   The magnitude of Xprod represents the parallelogram area formed by the two vectors
  //   The sign indicates the rotation direction from a1 to a2 (CCW = positive, CW = negative)
  //
  if (global_plan_.size() > 3)
  {
    // Create two vectors:
    // Vector 1 (a1): from path point 0 to path point 2 (path direction)
    double a11 =
        global_plan_[2].pose.position.x - global_plan_[0].pose.position.x;
    double a12 =
        global_plan_[2].pose.position.y - global_plan_[0].pose.position.y;

    // Vector 2 (a2): from nearest path point to control point (position error)
    double a21 =
        -pose_nearest_robot.pose.position.x + pose_control.pose.position.x;
    double a22 =
        -pose_nearest_robot.pose.position.y + pose_control.pose.position.y;

    // Cross product: determines which side of the path the robot is on
    // Positive = left side, Negative = right side, Zero = on path
    double Xprod = a11 * a22 - a12 * a21;
    int sign;
    if (Xprod > 0)
    {
      sign = -1;  // Robot is on left side of path
    }
    else if (Xprod < 0)
    {
      sign = 1;   // Robot is on right side of path
    }
    else
    {
      sign = 0;   // Robot is exactly on path
    }

    // Calculate perpendicular distance from control point to path
    error_front_axle = sqrt(a21 * a21 + a22 * a22);

    // Convert distance error to angular error using atan2
    // Larger distances produce larger angular corrections
    theta_d = atan2(sign * error_front_axle, 1);

    // Reduce cross-track correction when backing up close to goal with priority adjustment
    // This prevents overcorrection during precise final positioning
    if (!go_forward_ && priority_angle_adjustment_ && distance_to_goal < 0.65)
    {
      theta_d = theta_d/2;
    }
  }
  else
  {
    // Path is too short (< 3 points), can't calculate cross-track error
    theta_d = 0;
  }

  // ============================================================================
  // STEP 8: COMBINE ERRORS INTO STEERING COMMAND
  // ============================================================================
  // delta is the final steering angle command, combining:
  // - theta_e (heading error): makes robot point towards lookahead target
  // - theta_d (cross-track error): keeps robot on the path
  // Weights determine relative importance of each error term
  delta = theta_e * weight_theta_e_ + theta_d * weight_theta_d_;

  // ============================================================================
  // STEP 9: VELOCITY CONTROL - TWO MODES BASED ON DISTANCE TO GOAL
  // ============================================================================
  // Mode A: FAR FROM GOAL - Use full speed with curve-based adjustments
  // Mode B: NEAR GOAL - Use proportional slowdown for precise arrival
  if (error_goal_x * error_goal_x + error_goal_y * error_goal_y >
          error_to_start_stop_ * error_to_start_stop_ &&
      is_near_goal_ == false)
  {
    // -------------------------------------------------------------------------
    // MODE A: FAR FROM GOAL - NORMAL PATH FOLLOWING
    // -------------------------------------------------------------------------
    // Adjust speed based on steering angle (slow down for sharp turns)

    if (abs(delta) > 0.3 || low_speed_ == true)
    {
      // CASE 1: SHARP TURN (|delta| > 0.3 rad ≈ 17°) or LOW SPEED ZONE
      // Use minimum velocity to ensure safe navigation through tight curves
      if (!go_forward_)
      {
        limit_vel = -vel_x_when_more_angle_;  // Slow backward speed
      }
      else
      {
        limit_vel = vel_x_when_more_angle_;   // Slow forward speed
      }

      // Reduce velocity further based on actual steering angle
      // cos(steering_angle_/2) reduces speed when wheels are turned
      limit_vel = limit_vel * cos(steering_angle_/2);

      // Calculate acceleration to reach target velocity
      acc_vel_x = weight_acc_ * (limit_vel - robot_vel_.linear.x);

      // Limit acceleration to prevent jerky motion
      acc_vel_x = std::min(0.7, acc_vel_x);
      acc_vel_x = std::max(-0.7, acc_vel_x);
    }
    else if (abs(delta) > 0.15)
    {
      // CASE 2: MODERATE TURN (0.15 < |delta| < 0.3 rad, approx 9-17°)
      // Use 60% of maximum velocity
      // Change to 40 %
      if (!go_forward_)
      {
        limit_vel = -0.4 * max_vel_x_;
      }
      else
      {
        limit_vel = 0.4 * max_vel_x_;
      }

      // Apply steering angle compensation
      limit_vel = limit_vel * cos(steering_angle_/2);

      // Calculate and limit acceleration
      acc_vel_x = weight_acc_ * (limit_vel - robot_vel_.linear.x);
      acc_vel_x = std::min(0.7, acc_vel_x);
      acc_vel_x = std::max(-0.7, acc_vel_x);
    }
    else
    {
      // CASE 3: STRAIGHT OR GENTLE CURVE (|delta| < 0.15 rad ≈ 9°)
      // Use maximum velocity for efficient straight-line travel
      if (!go_forward_)
      {
        limit_vel = -max_vel_x_;
      }
      else
      {
        limit_vel = max_vel_x_;
      }

      // Apply steering angle compensation
      limit_vel = limit_vel * cos(steering_angle_/2);

      // Calculate and limit acceleration
      acc_vel_x = weight_acc_ * (limit_vel - robot_vel_.linear.x);
      acc_vel_x = std::min(0.7, acc_vel_x);
      acc_vel_x = std::max(-0.7, acc_vel_x);
    }

    // Integrate acceleration over time step to get new velocity
    vel_x = acc_vel_x * dt_ + robot_vel_.linear.x;

    // Apply absolute velocity limits
    vel_x = std::min(vel_x, max_vel_x_);
    vel_x = std::max(vel_x, -max_vel_x_);

    // Calculate steering command with proportional control
    angular_z = k_p_ * delta;

    // Limit steering angle to maximum allowed
    angular_z = std::min(angular_z, max_angular_z_);
    angular_z = std::max(angular_z, -max_angular_z_);
  }
  else
  {
    // -------------------------------------------------------------------------
    // MODE B: NEAR GOAL - PROPORTIONAL SLOWDOWN FOR PRECISE ARRIVAL
    // -------------------------------------------------------------------------
    is_near_goal_ = true;
    double vel_x_target;

    // Velocity proportional to remaining distance (0.25 is the proportional gain)
    // Closer to goal = slower speed for precise positioning
    if (!go_forward_)
    {
      vel_x_target = -0.25 * distance_to_goal;
    }
    else
    {
      vel_x_target = 0.25 * distance_to_goal;
    }

    // Enforce minimum velocity threshold of 0.2 m/s
    // Prevents velocity from becoming too small (which might cause stalling or slow convergence)
    if (vel_x_target < 0 and vel_x_target > -0.2)
    {
      vel_x_target = -0.2;
    }
    if (vel_x_target > 0 and vel_x_target < 0.2)
    {
      vel_x_target = 0.2;
    }

    // Reduce target velocity based on steering angle
    // More aggressive compensation (2/3 factor) for final approach accuracy
    vel_x_target = vel_x_target * cos(steering_angle_*2/3);

    // Calculate acceleration to smoothly reach target velocity
    acc_vel_x = weight_acc_ * (vel_x_target - robot_vel_.linear.x);

    // Higher acceleration limits allowed for goal approach (1.2 vs 0.7)
    // Allows faster deceleration when approaching goal
    acc_vel_x = std::min(1.2, acc_vel_x);
    acc_vel_x = std::max(-1.2, acc_vel_x);

    // Integrate acceleration to get new velocity
    vel_x = acc_vel_x * dt_ + robot_vel_.linear.x;

    // Apply velocity limits based on whether in low speed zone
    if (!low_speed_)
    {
      // Normal velocity limits
      vel_x = std::min(vel_x, max_vel_x_);
      vel_x = std::max(vel_x, -max_vel_x_);
    }
    else
    {
      // Restricted velocity limits in low speed zones (near obstacles, tight spaces, etc.)
      vel_x = std::min(vel_x, vel_x_when_more_angle_);
      vel_x = std::max(vel_x, -vel_x_when_more_angle_);
    }

    // Calculate steering command (same as Mode A)
    angular_z = k_p_ * delta;
    angular_z = std::min(angular_z, max_angular_z_);
    angular_z = std::max(angular_z, -max_angular_z_);

    // -------------------------------------------------------------------------
    // GOAL REACHED CHECK
    // -------------------------------------------------------------------------
    // If within position tolerance of goal, stop and prepare for final rotation
    if (abs(distance_to_goal) < xy_goal_tolerance_)
    {
      // Stop all motion
      vel_x = 0;
      angular_z = 0;

      // Reset near-goal flag for next path
      is_near_goal_ = false;

      // Check if we just corrected position after rotation
      if (correcting_position_after_rotate_)
      {
        // Position corrected, now retry rotation
        ROS_INFO("Position correction complete (%.3f m). Retrying final rotation...", distance_to_goal);
        correcting_position_after_rotate_ = false;
        rotate_to_goal_ = true;  // Trigger rotation again
      }
      // Determine if final rotation to goal orientation is needed
      else if (ignore_last_rotate_)
      {
        // Skip final rotation, mark goal as reached immediately
        goal_reached_ = true;
      }
      else
      {
        // Trigger final rotation to match goal orientation
        rotate_to_goal_ = true;
      }
    }
    else if (correcting_position_after_rotate_)
    {
      // Still correcting position, log progress
      ROS_INFO_THROTTLE(1.0, "Correcting position: %.3f m remaining (tolerance: %.3f m)",
                       distance_to_goal, xy_goal_tolerance_);
    }
  }

  // ============================================================================
  // STEP 10: APPLY DIRECTION-DEPENDENT TRANSFORMATIONS
  // ============================================================================
  // For backward motion, invert the steering angle
  // This accounts for the reversed kinematics when moving backwards
  if (!go_forward_)
  {
    angular_z = -angular_z;
  }

  // ============================================================================
  // STEP 11: SET OUTPUT VELOCITY COMMANDS
  // ============================================================================
  // Write the calculated velocities to the output command message
  cmd_vel.twist.linear.x = vel_x > 0 ? std::min(vel_x, max_vel_requested) : std::max(-max_vel_requested, vel_x);        // Linear velocity (forward/backward)
  //TODO: add request limit for angular velocity
  cmd_vel.twist.angular.z = angular_z;   // Angular velocity (steering angle for carlike)


  return true;
}

void AgfLocalPlannerROS::findPointInPath(
    const geometry_msgs::PoseStamped& pose_robot,
    const std::vector<geometry_msgs::PoseStamped>& path,
    geometry_msgs::PoseStamped& pose, double distance, int& number_in_path)
{
  double min_distance = 10000.0;  // 10^2
  for (int i = 0; i < path.size(); i++)
  {
    // dx, dy để tính khoảng cách từ robot tới từng điểm trong path
    double dx = pose_robot.pose.position.x - path[i].pose.position.x;
    double dy = pose_robot.pose.position.y - path[i].pose.position.y;
    // Không cần sqrt đê giảm tính toán mà vẫn so sánh được
    double dist_sq = (distance - sqrt(dx * dx + dy * dy)) *
                     (distance - sqrt(dx * dx + dy * dy));
    // dis_robot_to_path = sqrt(dx*dx + dy*dy)
    // dist_sq = (distance - dis_robot_to_path)^2
    // Tìm điềm gần nhất
    if (dist_sq < min_distance)
    {
      min_distance = dist_sq;
      number_in_path = i;
    }
  }
  pose = path[number_in_path];
}

double AgfLocalPlannerROS::quaternionToRPY(double qx, double qy, double qz,
                                           double qw)
{
  // The incoming geometry_msgs::Quaternion is transformed to a tf::Quaterion
  tf2::Quaternion quat;
  quat.setX(qx);
  quat.setY(qy);
  quat.setZ(qz);
  quat.setW(qw);

  // The tf::Quaternion has a method to acess roll pitch and yaw
  double roll, pitch, yaw;
  tf2::Matrix3x3(quat).getRPY(roll, pitch, yaw);
  return yaw;
}

double AgfLocalPlannerROS::normalizeAngle(double angle)
{
  while (angle > M_PI)
  {
    angle -= 2 * M_PI;
  }
  while (angle < -M_PI)
  {
    angle += 2 * M_PI;
  }
  return angle;
}

bool AgfLocalPlannerROS::isGoalReached()
{
  if (!initialized_)
  {
    ROS_ERROR("This planner has not been initialized, please call initialize() "
              "before using this planner");
    return mbf_msgs::ExePathResult::NOT_INITIALIZED;
  }

  if (goal_reached_)
  {
    ROS_INFO("GOAL Reached!");
    return true;
  }
  return false;
}

void AgfLocalPlannerROS::resetSafetyZone(){
  // Default safety zones: all directions safe
  msg_safety_zone_.ints = {-1, -1, -1, -1};
}
}  // namespace agf_local_planner
