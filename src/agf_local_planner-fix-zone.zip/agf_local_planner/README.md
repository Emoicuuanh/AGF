# Format C++ code

```json
{
  // Add this line to ~/.config/Code/User/settings.json
  "C_Cpp.clang_format_fallbackStyle": " {ReflowComments: false, ColumnLimit: 80, BreakBeforeBraces: Allman, SpacesBeforeTrailingComments: 2, AlignTrailingComments: true, PointerAlignment: Left, }"
}
```
