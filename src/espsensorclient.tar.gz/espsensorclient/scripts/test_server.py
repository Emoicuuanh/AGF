import socket

def send_command_to_esp(command):
    host = '192.168.0.124'  # Địa chỉ IP của ESP32
    port = 80          # Port của ESP32

    try:
        with socket.socket(socket.AF_INET, socket.SOCK_STREAM) as s:
            s.connect((host, port))
            s.sendall(command.encode() + b'\r\n')  # Gửi lệnh tới ESP32

            # Nhận phản hồi từ ESP32
            response = s.recv(1024).decode()  # Chờ nhận phản hồi từ ESP32
            print('Received from ESP32:', response)

    except socket.error as e:
        print(f"Error connecting to ESP32: {e}")

if __name__ == "__main__":
    while True:
        command = input("Nhập lệnh để gửi tới ESP32 (start_conveyor / stop_conveyor): ").strip()
        if command in ["start_conveyor", "stop_conveyor"]:
            send_command_to_esp(command)
        else:
            print("Lệnh không hợp lệ, vui lòng nhập lại!")