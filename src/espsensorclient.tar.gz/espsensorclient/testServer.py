import socket
import time

# Define the host and port to listen on
HOST = "127.0.0.1"  # Use '0.0.0.0' to accept connections from any IP address
PORT = 12345  # Port to listen on

# Create a TCP/IP socket
with socket.socket(socket.AF_INET, socket.SOCK_STREAM) as server_socket:

    server_socket.setsockopt(socket.SOL_SOCKET, socket.SO_REUSEADDR, 1)
    # Bind the socket to the address and port
    server_socket.bind((HOST, PORT))

    # Listen for incoming connections
    server_socket.listen()
    print(f"Server is listening on {HOST}:{PORT}...")

    while True:
        # Accept a client connection
        client_socket, client_address = server_socket.accept()
        print(f"Accepted connection from {client_address}")

        try:
            while True:
                # Receive a request from the client
                request = client_socket.recv(1024).decode()

                if not request:
                    # If no data is received, the client might have disconnected
                    print(f"Client {client_address} disconnected.")
                    break

                print(f"Received request: '{request}'")

                # Check if the request is valid (e.g., the client sends "GET_DATA")
                if (
                    request.strip() == "start_conveyor"
                    or request.strip() == "stop_conveyor"
                ):
                    print(f"GET CONVEYOR REQUEST {client_address}: '{request}'")
                    # Send the message to the client
                    message = "OK" + "\r\n"
                    client_socket.sendall(message.encode())
                    print(f"Sent message: '{message}'")

                else:
                    # Send the message to the client
                    message = "#1.0#1.0%\n"
                    client_socket.sendall(message.encode())
                    print(f"Sent message: '{message}'")
                # Wait for a short time before processing the next request
                time.sleep(0.1)
        except ConnectionResetError:
            print(f"Client {client_address} disconnected.")
        finally:
            # Clean up the connection
            client_socket.close()
