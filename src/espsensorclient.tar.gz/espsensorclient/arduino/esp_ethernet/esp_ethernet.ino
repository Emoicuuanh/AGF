// #include <Arduino.h>

#include <WiFi.h>
#include <SoftwareSerial.h>
#include <esp_wifi.h>
#include <SPI.h>
#include <Ethernet.h>

const char *ssid = "JIG-MOLD";
const char *password = "12345678901234567890123456";
// const char *ssid = "galaxy";
// const char *password = "12345678";
const char *espHostname = "MKAC-AGF";

#define USE_ETH true
#define USE_WF true

// Define the W5500 Ethernet module pins with the new GPIO assignments
#define W5500_CS_PIN 10
#define W5500_RST_PIN 5
#define W5500_INT_PIN 41
#define W5500_CLK_PIN 12
#define W5500_MOSI_PIN 11
#define W5500_MISO_PIN 13

// MAC address for your Ethernet shield (must be unique on your network)
byte mac[] = { 0xDE, 0xAD, 0xBE, 0xEF, 0xFE, 0xED };

// Static IP address configuration
IPAddress ip(192, 168, 0, 55);       // Static IP address
IPAddress subnet(255, 255, 255, 0);  // Subnet mask
IPAddress gateway(192, 168, 0, 1);   // Default gateway
IPAddress myDns(192, 168, 0, 1);     // DNS serverWF address

// Create an EthernetServer object to handle TCP connections

// Set up WiFi serverWF on port 80
WiFiServer serverWF(80);
WiFiClient clientWF;

EthernetServer serverETH(1234);
EthernetClient clientETH;

bool clientsConnected = false;

const int led_Red = 7;            // Đèn đỏ, báo băng tải hoạt động với AGF
const int led_Green = 6;          // Đèn xanh, báo băng tải hoạt động chế độ thường
const int request_agf_mode = 15;  // yêu cầu chuyển băng tải sang chế độ hoạt động với AGF

// update in out canon
const int Confirm_AGF_Mode = 35;            // Băng tải chuyển sang chế độ hoạt động vs AGF
const int Film_Rolling_Machine_Error = 36;  // Thông báo lỗi từ máy cuốn film
const int Request_AGF_Mode_1 = 16;          // yêu cầu chuyển băng tải sang chế độ hoạt động với AGF

bool state_Confirm_AGF_Mode;
bool state_Film_Rolling_Machine_Error;
bool warning;

int retryWFClient = 0;
int retryETClient = 0;

String responseConveyor = "$1*";
String response_warning;

void control_conveyor(String request) {
  state_Confirm_AGF_Mode = digitalRead(Confirm_AGF_Mode);
  if (request.indexOf("stop") != -1) {
    digitalWrite(request_agf_mode, HIGH);    // Tắt băng tải, kéo lên 24v
    digitalWrite(Request_AGF_Mode_1, HIGH);  // Tắt băng tải, kéo lên 24v

    if (state_Confirm_AGF_Mode == 1) {
      digitalWrite(led_Red, HIGH);
      digitalWrite(led_Green, LOW);
      responseConveyor = "$STOPPED*";
    } else if (state_Confirm_AGF_Mode == 0) {
      digitalWrite(led_Red, LOW);
      digitalWrite(led_Green, HIGH);
    }
  } else if (request.indexOf("start") != -1) {
    digitalWrite(request_agf_mode, LOW);    // Bật băng tải, kéo về 0v
    digitalWrite(Request_AGF_Mode_1, LOW);  // Bật băng tải, kéo về 0v
    if (state_Confirm_AGF_Mode == 1) {
      digitalWrite(led_Red, HIGH);
      digitalWrite(led_Green, LOW);
    } else if (state_Confirm_AGF_Mode == 0) {
      digitalWrite(led_Red, LOW);
      digitalWrite(led_Green, HIGH);
      responseConveyor = "$STARTED*";
    }
  }
}

void readMacAddress() {
  uint8_t baseMac[6];
  esp_err_t ret = esp_wifi_get_mac(WIFI_IF_STA, baseMac);
  if (ret == ESP_OK) {
    Serial.printf("MAC Address: %02x:%02x:%02x:%02x:%02x:%02x\n",
                  baseMac[0], baseMac[1], baseMac[2],
                  baseMac[3], baseMac[4], baseMac[5]);
  } else {
    Serial.println("Failed to read MAC address");
  }
}

void warnning_error() {
  if (warning == 1) {
    response_warning = "WARNNING";
    Serial.print("Có lỗi trên máy cuốn film");
  } else {
    response_warning = "OKE";
  }
}

void getPose(const String &input, char delimiter, String fields[], int maxFields, String &error) {
  int start = 0;
  int index = 0;

  // Skip the leading delimiter '#'
  if (input[0] == delimiter) {
    start = 1;
  }

  while (index < maxFields) {
    int end = input.indexOf(delimiter, start);

    if (end == -1) {  // No more delimiters, process the last field
      fields[index++] = input.substring(start);
      break;
    } else {
      fields[index++] = input.substring(start, end);
      start = end + 1;
    }
  }

  // Validate if we got exactly maxFields fields
  if (index < maxFields) {
    error = "Incomplete fields";
  } else {
    error = "";  // No error
  }
}

void ETHSetup() {
  // Initialize the W5500 module
  pinMode(W5500_RST_PIN, OUTPUT);
  pinMode(W5500_INT_PIN, INPUT);
  digitalWrite(W5500_RST_PIN, LOW);   // Reset the W5500 module
  delay(100);                         // Wait for reset to complete
  digitalWrite(W5500_RST_PIN, HIGH);  // Release reset

  // Initialize SPI with the correct pin definitions
  SPI.begin(W5500_CLK_PIN, W5500_MISO_PIN, W5500_MOSI_PIN);

  // Set up the Ethernet library with W5500-specific pins
  Ethernet.init(W5500_CS_PIN);

  // Start the Ethernet connection with static IP configuration
  // Ethernet.begin(mac, ip);
  Ethernet.begin(mac, ip, myDns, gateway, subnet);



  Serial.println("Wait for ethernet link*");
  while (Ethernet.linkStatus() != LinkON) {
    delay(500);
    Serial.print("*");
  } 
    Serial.println("Ethernet link is active.");
    Serial.print("IP WIFI Address: ");
    Serial.println(Ethernet.localIP());
    // Start listening for incoming TCP connections
    serverETH.begin();
}

void WFSetup() {
  WiFi.begin(ssid, password);
  Serial.println("Connecting to WiFi...");

  while (WiFi.status() != WL_CONNECTED) {
    delay(500);
    Serial.print(".");
  }

  Serial.println("\nWiFi connected");
  Serial.print("IP WIFI Address: ");
  Serial.println(WiFi.localIP());
  readMacAddress();
  serverWF.begin();

  if (WiFi.status() != WL_CONNECTED) {
    Serial.println("WiFi connection is down!");
  } else {
    Serial.println("WiFi is connected!");
    Serial.print("IP Address: ");
    Serial.println(WiFi.localIP());
  }
}

void setup() {
  // Setup Serial Monitor
  Serial.begin(115200);
  delay(100);
  Serial.println("INITIALIZING");

  ETHSetup();
  delay(100);
  WFSetup();
  
  // Configure IO pins

  pinMode(request_agf_mode, OUTPUT);
  pinMode(led_Green, OUTPUT);
  pinMode(led_Red, OUTPUT);
  digitalWrite(request_agf_mode, LOW);  // Bật băng tải mặc định, kéo xuống 0V

  // Update trạng thái chân in out bổ sung

  pinMode(Confirm_AGF_Mode, INPUT);
  pinMode(Film_Rolling_Machine_Error, INPUT);
  pinMode(Request_AGF_Mode_1, OUTPUT);
  digitalWrite(led_Green, LOW);  // Kéo xuống 0V, bật đèn xanh báo hệ thống hoạt động
  digitalWrite(led_Red, HIGH);
}

void loop() {
  String poseCmd = "";
  // Serial.println("UPDATE");
  if (true) {
    state_Confirm_AGF_Mode = digitalRead(Confirm_AGF_Mode);
    if (state_Confirm_AGF_Mode == 1) {
      digitalWrite(led_Red, HIGH);
      digitalWrite(led_Green, LOW);
    } else if (state_Confirm_AGF_Mode == 0) {
      digitalWrite(led_Red, LOW);
      digitalWrite(led_Green, HIGH);
    }
  }
  if (true) {
    state_Film_Rolling_Machine_Error = digitalRead(Film_Rolling_Machine_Error);
    if (state_Film_Rolling_Machine_Error == 1) {
      warning = 1;  // Thông báo hệ thống đang có cảnh báo
    } else {
      warning = 0;
    }
  }

  clientWF = serverWF.available();
  clientETH = serverETH.available();

  if(clientETH) {
    if (clientETH.connected())
    {
      // Process Pose from Raspberry
      if (clientETH.available()) {
        String pose = clientETH.readStringUntil('/n');
        String poseFields[7];
        String poseErr = "";
        getPose(pose, '#', poseFields, 7, poseErr);
        if (poseErr == "") {
          poseCmd = "#" + String(poseFields[0]) + "#" + String(poseFields[1]) + "#" + String(poseFields[2]) + "#" + String(poseFields[3]) + "#" + String(poseFields[4]) + "#" + String(poseFields[5]) + "#" + String(poseFields[6]) + "%";
          clientETH.println("$OK*");
        } else {
          Serial.println(poseErr);
          clientETH.println("$NG*");
        }
        delay(10);
      }
    }
    else {
      Serial.println("ETH CLIENT IS DISCONNECTED");
      clientETH.stop();
    }
  }
  if (clientWF){
    if (clientWF.connected())
    {
      // Process Conveyor
      if (clientWF.available()) {
        conveyorReady = true;
        String request = clientWF.readStringUntil('/n');
        Serial.print("request: ");
        Serial.println(request);
        if (request.indexOf("stop") != -1 || request.indexOf("start") != -1) {
          control_conveyor(request);
          Serial.println("conveyor controlling..");
          Serial.println(responseConveyor);
        }
      }
      String response = poseCmd + responseConveyor;
      Serial.print("SEND DATA WF: ");
      clientWF.print(response);
      Serial.println(response);
      delay(10);
    }
    else
    {
      Serial.println("WF CLIENT IS DISCONNECTED")
      clientWF.stop();
    }
  }
}
