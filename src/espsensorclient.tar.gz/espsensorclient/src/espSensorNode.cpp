#include <ros/ros.h>
#include "espSensor.hpp"
#include "std_msgs/Int32MultiArray.h"

int main(int argc, char **argv){
    ros::init(argc, argv, "espClientNode");
    ros::NodeHandle nh;

    int port;
    std::string ip_address;
    int get_io_rate;

    nh.getParam("ip_address", ip_address);
    nh.getParam("port", port);
    nh.getParam("get_io_rate", get_io_rate);

    ros::Rate loop_rate(get_io_rate);

    // ROS_INFO("Driver parameters : %d | IP : %s : %d", get_io_rate, ip_address.c_str(), port);

    EspSensor espSensor(ip_address, port, nh, loop_rate);

    espSensor.startClient();

    return 0;

}