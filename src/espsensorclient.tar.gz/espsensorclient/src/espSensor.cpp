#include "espSensor.hpp"

bool EspSensor::connect()
{
  try
  {
    if (socket_.is_open())
    {
      socket_.close();
      ROS_INFO("Socket closed");
    }
    boost::asio::ip::tcp::endpoint endpoint(
        boost::asio::ip::address::from_string(server_ip_), port_);
    ROS_INFO("Attempting to connect to %s:%d", server_ip_.c_str(), port_);

    socket_.connect(endpoint);

    if (socket_.is_open())  // Check if the socket is actually connected
    {
      ROS_INFO("Connected to server");
      return true;  // Connection successful
    }
    else
    {
      ROS_ERROR("Failed to connect: Socket is not open after connect call.");
      return false;  // Connection failed
    }
  }
  catch (const std::exception& e)
  {
    ROS_ERROR("Failed to connect: %s", e.what());
    return false;  // Connection failed
  }
}

std::string EspSensor::readSensor()
{
  // std::lock_guard<std::mutex> lock(tcp_mutex_);
  // boost::asio::write(socket_, boost::asio::buffer("DIST\n"));
  boost::asio::streambuf buffer;
  boost::asio::read_until(socket_, buffer, '*');
  std::istream input_stream(&buffer);
  std::string data;
  std::getline(input_stream, data, '*');
  std::cout << data << std::endl;
  // Assuming received data is of string type, you can modify it as per your data format
  ROS_INFO("Received data: %s", data.c_str());
  return data;
}

// std::string EspSensor::readSensor()
// {
//   std::lock_guard<std::mutex> lock(tcp_mutex_);
//   static std::string accumulated_data;

//   try
//   {

//     if (!socket_.is_open())
//     {
//       ROS_ERROR("Socket is closed.");
//       return "";
//     }

//     boost::asio::streambuf buffer;

//     // Read until '*' is encountered
//     boost::asio::read_until(socket_, buffer, '*');

//     // Extract the chunk of data up to '*'
//     std::istream input_stream(&buffer);
//     std::string chunk;
//     std::getline(input_stream, chunk, '*');

//     ROS_INFO("CHUNK: %s", chunk.c_str());

//     // Append the chunk and '*' to the accumulated data
//     accumulated_data += chunk;

//     // Check if '*' is present in the accumulated data
//     std::size_t pos = accumulated_data.find('*');
//     if (pos != std::string::npos)
//     {
//       // Extract the complete message ending with '*'
//       std::string complete_data = accumulated_data.substr(0, pos + 1);

//       // Remove the processed message from the buffer
//       accumulated_data.erase(0, pos + 1);

//       ROS_INFO("Complete data received: %s", complete_data.c_str());
//       return complete_data;
//     }
//   }
//   catch (const boost::system::system_error& e)
//   {
//     ROS_ERROR_ONCE("Error reading data: %s", e.what());
//   }
//   catch (const std::exception& e)
//   {
//     ROS_ERROR_ONCE("Unexpected error: %s", e.what());
//   }

//   return "";  // Return an empty string if no complete data is found
// }

// std::string EspSensor::readSensor()
// {
//   std::lock_guard<std::mutex> lock(tcp_mutex_);
//   static std::string accumulated_data;

//   try
//   {
//     // Set a timeout for socket operations
//     boost::asio::steady_timer timer(socket_.get_executor());
//     timer.expires_after(std::chrono::seconds(2));

//     // Perform asynchronous operations with timeout
//     boost::asio::streambuf buffer;
//     auto read_result = boost::asio::async_read_until(socket_, buffer, '*',
//                                                      boost::asio::use_future);

//     // Wait for the read or timeout
//     if (read_result.wait_for(std::chrono::seconds(2)) ==
//         std::future_status::timeout)
//     {
//       // socket_.close();  // Close the socket if the timeout expires
//       ROS_WARN("Timeout occurred while reading data.");
//       return "";
//     }

//     // Get the result of the read operation
//     read_result.get();

//     // Process the buffer and extract data
//     std::istream input_stream(&buffer);
//     std::string chunk;
//     std::getline(input_stream, chunk, '*');  // Read up to '*'

//     accumulated_data +=
//         chunk + "*";  // Append chunk and '*' to accumulated data

//     // Check if accumulated data contains a complete message
//     std::size_t pos = accumulated_data.find('*');
//     if (pos != std::string::npos)
//     {
//       std::string complete_data =
//           accumulated_data.substr(0, pos + 1);  // Extract the complete message
//       accumulated_data.erase(0, pos + 1);       // Erase the processed message
//       ROS_INFO("Complete data received: %s", complete_data.c_str());
//       return complete_data;
//     }
//   }
//   catch (const boost::system::system_error& e)
//   {
//     ROS_ERROR("Error reading data: %s", e.what());
//   }
//   catch (const std::exception& e)
//   {
//     ROS_ERROR("Unexpected error: %s", e.what());
//   }

//   return "";  // Return an empty string if no complete data is found
// }

std::vector<float> EspSensor::processData(const std::string& input)
{
  std::vector<float> distances;

  ROS_INFO("INPUT: %s", input.c_str());

  // Find the positions of the delimiters
  size_t dis1Pos = input.find('#');
  size_t dis2Pos = input.find('#', dis1Pos + 1);
  size_t dis3Pos = input.find('#', dis2Pos + 1);
  size_t dis4Pos = input.find('#', dis3Pos + 1);
  size_t dis5Pos = input.find('#', dis4Pos + 1);
  size_t dis6Pos = input.find('#', dis5Pos + 1);
  size_t dis7Pos = input.find('#', dis6Pos + 1);
  size_t endPos = input.find('%');

  // Extract the substrings and convert to integers
  if (dis1Pos != std::string::npos && dis2Pos != std::string::npos &&
      dis3Pos != std::string::npos && dis4Pos != std::string::npos &&
      dis5Pos != std::string::npos && dis6Pos != std::string::npos &&
      dis7Pos != std::string::npos && endPos != std::string::npos)
  {
    std::string distance_1_str =
        input.substr(dis1Pos + 1, dis2Pos - dis1Pos - 1);
    std::string distance_2_str =
        input.substr(dis2Pos + 1, dis3Pos - dis2Pos - 1);
    std::string distance_3_str =
        input.substr(dis3Pos + 1, dis4Pos - dis3Pos - 1);
    std::string distance_4_str =
        input.substr(dis4Pos + 1, dis5Pos - dis4Pos - 1);
    std::string distance_5_str =
        input.substr(dis5Pos + 1, dis6Pos - dis5Pos - 1);
    std::string distance_6_str =
        input.substr(dis6Pos + 1, dis7Pos - dis6Pos - 1);
    std::string distance_7_str =
        input.substr(dis7Pos + 1, endPos - dis7Pos - 1);

    ROS_INFO(
        "distanceStr: %s | %s | %s | %s | %s | %s | %s", distance_1_str.c_str(),
        distance_2_str.c_str(), distance_3_str.c_str(), distance_4_str.c_str(),
        distance_5_str.c_str(), distance_6_str.c_str(), distance_7_str.c_str());
    try
    {
      float distance_1 = std::stof(distance_1_str);
      float distance_2 = std::stof(distance_2_str);
      float distance_3 = std::stof(distance_3_str);
      float distance_4 = std::stof(distance_4_str);
      float distance_5 = std::stof(distance_5_str);
      float distance_6 = std::stof(distance_6_str);
      float distance_7 = std::stof(distance_7_str);

      distances.push_back(distance_1);
      distances.push_back(distance_2);
      distances.push_back(distance_3);
      distances.push_back(distance_4);
      distances.push_back(distance_5);
      distances.push_back(distance_6);
      distances.push_back(distance_7);
    }
    catch (const std::invalid_argument& e)
    {
      std::cerr << "Invalid argument: " << e.what() << std::endl;
    }
    catch (const std::out_of_range& e)
    {
      std::cerr << "Out of range: " << e.what() << std::endl;
    }
  }

  return distances;
}

std::string EspSensor::processResponse(const std::string& input)
{
  ROS_INFO("response: %s", input.c_str());
  // Find the positions of the delimiters
  size_t dis1Pos = input.find('$');
  size_t endPos = input.find('*');
  // Extract the substrings and convert to integers
  if (dis1Pos != std::string::npos && endPos != std::string::npos)
  {
    std::string responseStr = input.substr(dis1Pos + 1, endPos - 1);
    ROS_INFO("responseStr: %s", responseStr.c_str());
    return responseStr;
  }
}

void EspSensor::getInitParameters()
{
  nh_.param<std::string>("sensor_tf/sensor_frame", sensor1_frame, "espSensor1");
  nh_.param<std::string>("sensor_tf/base_frame", base_frame, "map");

  nh_.param("sensor_tf/x", sensor1_x, 0.0);
  nh_.param("sensor_tf/y", sensor1_y, 0.0);
  nh_.param("sensor_tf/z", sensor1_z, 0.0);
  nh_.param("sensor_tf/qx", sensor1_qx, 0.0);
  nh_.param("sensor_tf/qy", sensor1_qy, 0.0);
  nh_.param("sensor_tf/qz", sensor1_qz, 0.0);
  nh_.param("sensor_tf/qw", sensor1_qw, 1.0);
  nh_.param("pick_frame/x", pick_frame_x, 0.0);
  nh_.param("pick_frame/y", pick_frame_y, 0.0);
  nh_.param("pick_frame/z", pick_frame_z, 0.0);
  nh_.param("turn_frame/x", turn_frame_x, 0.0);
  nh_.param("turn_frame/y", turn_frame_y, 0.0);
  nh_.param("turn_frame/z", turn_frame_z, 0.0);
  nh_.param("wait_frame/x", wait_frame_x, 0.0);
  nh_.param("wait_frame/y", wait_frame_y, 0.0);
  nh_.param("wait_frame/z", wait_frame_z, 0.0);
  nh_.param("correct_angle_frame/x", correct_angle_frame_x, 0.0);
  nh_.param("correct_angle_frame/y", correct_angle_frame_y, 0.0);
  nh_.param("correct_angle_frame/z", correct_angle_frame_z, 0.0);

  nh_.param("sensor_tf/sensor_distance", sensor_distance,
            1.0);  // distance in  Y direction
  nh_.param("sensor_tf/inplace_tolerance", inplace_tolerance, 0.1);

  // sensor2_x = sensor1_x;
  // sensor2_y = sensor1_y + sensor_distance;
  // sensor2_z = sensor1_z;
}

void EspSensor::publishSensorFrame()
{
  sensor_static_transform.header.stamp = ros::Time::now();
  sensor_static_transform.header.frame_id = base_frame;
  sensor_static_transform.child_frame_id = sensor1_frame;
  sensor_static_transform.transform.translation.x = sensor1_x;
  sensor_static_transform.transform.translation.y = sensor1_y;
  sensor_static_transform.transform.translation.z = sensor1_z;
  sensor_static_transform.transform.rotation.x = sensor1_qx;
  sensor_static_transform.transform.rotation.y = sensor1_qy;
  sensor_static_transform.transform.rotation.z = sensor1_qz;
  sensor_static_transform.transform.rotation.w = sensor1_qw;

  static_broadcaster_.sendTransform(sensor_static_transform);
}

geometry_msgs::Pose
EspSensor::calculatePalletPosition(std::vector<float>& sensorData_)
{
  geometry_msgs::Pose palletPose;

  palletPose.position.x = sensorData_[0];
  palletPose.position.y = sensorData_[1];
  palletPose.position.z = sensorData_[2];
  palletPose.orientation.x = sensorData_[3];
  palletPose.orientation.y = sensorData_[4];
  palletPose.orientation.z = sensorData_[5];
  palletPose.orientation.w = sensorData_[6];

  return palletPose;
}

tf2::Quaternion EspSensor::eulerToQuaternion(float roll, float pitch, float yaw)
{
  tf2::Quaternion q;
  q.setRPY(roll, pitch, yaw);
  q.normalize();
  return q;
}

bool EspSensor::palletWidthReqCb(std_stamped_msgs::StringService::Request& req,
                                 std_stamped_msgs::StringService::Response& res)
{
  res.respond = "OK";
  ROS_INFO("INPUT STRING WIDTH REQUEST: %s", req.request.c_str());
  pallet_width = std::stof(req.request);
  ROS_INFO("Pallet width updated: %f", pallet_width);
  return true;
}

bool EspSensor::conveyorControlReqCb(
    std_stamped_msgs::StringService::Request& req,
    std_stamped_msgs::StringService::Response& res)
{
  // Send the command to ESP32
  std::string command = req.request;
  ROS_INFO("COMMAND: %s", command.c_str());
  if (command == "start" || command == "stop")
  {
    // Send command to ESP32
    std::string response = sendCommandToESP32(command);
    if (response != "")
    {
      res.respond = processResponse(cleanString(response));
    }
    else
    {
      res.respond = "NG";
    }
  }
  else
  {
    res.respond = "NG";
  }
  return true;
}

std::string EspSensor::sendCommandToESP32(const std::string& command)
{
  try
  {
    // Send the command
    boost::asio::write(socket_, boost::asio::buffer(command + "\r\n"));

    // Read the response from ESP32
    boost::asio::streambuf response;
    boost::asio::read_until(socket_, response, "\r\n");

    std::istream response_stream(&response);
    std::string response_str;
    std::getline(response_stream, response_str);

    return response_str;
  }
  catch (boost::system::system_error& e)
  {
    ROS_ERROR("Failed to send command to ESP32: %s", e.what());
    return "$1*";
  }
}

void EspSensor::updatePalletPosition(std::vector<float>& sensorData_)
{
  std::cout << "sensorData_: " << sensorData_[0] << " | " << sensorData_[1]
            << " | " << sensorData_[2] << " | " << sensorData_[3] << " | "
            << sensorData_[4] << " | " << sensorData_[5] << " | "
            << sensorData_[6] << std::endl;
  // Pallet edge
  edge_pallet_transform.header.stamp = ros::Time::now() + ros::Duration(0.1);
  edge_pallet_transform.header.frame_id = sensor1_frame;
  edge_pallet_transform.child_frame_id = "edge_pallet";
  edge_pallet_transform.transform.translation.x = sensorData_[0];
  edge_pallet_transform.transform.translation.y = sensorData_[1];
  edge_pallet_transform.transform.translation.z = sensorData_[2];

  tf2::Quaternion quat(sensorData_[3], sensorData_[4], sensorData_[5],
                       sensorData_[6]);
  quat.normalize();
  edge_pallet_transform.transform.rotation.x = quat.x();
  edge_pallet_transform.transform.rotation.y = quat.y();
  edge_pallet_transform.transform.rotation.z = quat.z();
  edge_pallet_transform.transform.rotation.w = quat.w();

  transform_broadcaster_.sendTransform(edge_pallet_transform);

  // Pallet frame
  tf2::Quaternion palletQuat = eulerToQuaternion(0.0, 0.0, 0.0);
  palletQuat.normalize();
  pallet_transform.header.stamp = ros::Time::now() + ros::Duration(0.1);
  pallet_transform.header.frame_id = "edge_pallet";
  pallet_transform.child_frame_id = pallet_frame;
  pallet_transform.transform.translation.x = -pallet_width / 2;
  pallet_transform.transform.rotation.x = palletQuat.x();
  pallet_transform.transform.rotation.y = palletQuat.y();
  pallet_transform.transform.rotation.z = palletQuat.z();
  pallet_transform.transform.rotation.w = palletQuat.w();
  transform_broadcaster_.sendTransform(pallet_transform);

  // Correct angle FL frame
  tf2::Quaternion pCorrectAngleQuat = eulerToQuaternion(0.0, 0.0, 0.0);
  pCorrectAngleQuat.normalize();
  pCorrectAngle_transform.header.stamp = ros::Time::now() + ros::Duration(0.1);
  pCorrectAngle_transform.header.frame_id = pallet_frame;
  pCorrectAngle_transform.child_frame_id = "pCorrectAngle";
  pCorrectAngle_transform.transform.translation.x = correct_angle_frame_x;
  pCorrectAngle_transform.transform.translation.y = correct_angle_frame_y;
  pCorrectAngle_transform.transform.translation.z = correct_angle_frame_z;
  pCorrectAngle_transform.transform.rotation.x = pCorrectAngleQuat.x();
  pCorrectAngle_transform.transform.rotation.y = pCorrectAngleQuat.y();
  pCorrectAngle_transform.transform.rotation.z = pCorrectAngleQuat.z();
  pCorrectAngle_transform.transform.rotation.w = pCorrectAngleQuat.w();
  transform_broadcaster_.sendTransform(pCorrectAngle_transform);

  // pPick Frame
  tf2::Quaternion pPickQuat = eulerToQuaternion(0.0, 0.0, 0.0);
  pPickQuat.normalize();
  pPick_transform.header.stamp = ros::Time::now() + ros::Duration(0.1);
  pPick_transform.header.frame_id = pallet_frame;
  pPick_transform.child_frame_id = "pPick";
  pPick_transform.transform.translation.x = pick_frame_x;
  pPick_transform.transform.translation.y = pick_frame_y;
  pPick_transform.transform.translation.z = pick_frame_z;
  pPick_transform.transform.rotation.x = pPickQuat.x();
  pPick_transform.transform.rotation.y = pPickQuat.y();
  pPick_transform.transform.rotation.z = pPickQuat.z();
  pPick_transform.transform.rotation.w = pPickQuat.w();
  transform_broadcaster_.sendTransform(pPick_transform);

  // pTurn Frame
  tf2::Quaternion pTurnQuat = eulerToQuaternion(0.0, 0.0, 0.0);
  pTurnQuat.normalize();
  pTurn_transform.header.stamp = ros::Time::now() + ros::Duration(0.1);
  pTurn_transform.header.frame_id = pallet_frame;
  pTurn_transform.child_frame_id = "pWait";
  pTurn_transform.transform.translation.x = turn_frame_x;
  pTurn_transform.transform.translation.y = turn_frame_y;
  pTurn_transform.transform.translation.z = turn_frame_z;
  pTurn_transform.transform.rotation.x = pTurnQuat.x();
  pTurn_transform.transform.rotation.y = pTurnQuat.y();
  pTurn_transform.transform.rotation.z = pTurnQuat.z();
  pTurn_transform.transform.rotation.w = pTurnQuat.w();
  transform_broadcaster_.sendTransform(pTurn_transform);

  // pWait Frame
  tf2::Quaternion pWaitQuat = eulerToQuaternion(0.0, 0.0, 0.0);
  pWaitQuat.normalize();
  pWait_transform.header.stamp = ros::Time::now() + ros::Duration(0.1);
  pWait_transform.header.frame_id = pallet_frame;
  pWait_transform.child_frame_id = "pTurn";
  pWait_transform.transform.translation.x = wait_frame_x;
  pWait_transform.transform.translation.y = wait_frame_y;
  pWait_transform.transform.translation.z = wait_frame_z;
  pWait_transform.transform.rotation.x = pWaitQuat.x();
  pWait_transform.transform.rotation.y = pWaitQuat.y();
  pWait_transform.transform.rotation.z = pWaitQuat.z();
  pWait_transform.transform.rotation.w = pWaitQuat.w();
  transform_broadcaster_.sendTransform(pWait_transform);
  ROS_INFO("update pallet frame");
}

void EspSensor::startClient()
{
  std::cout << "Starting ESP_SENSOR_NODE at: " << server_ip_.c_str() << ":"
            << port_ << std::endl;
  getInitParameters();
  publishSensorFrame();

  int cout_connect_false = 0;
  double last_pose = 0.0;
  ros::Time last_change_time = ros::Time::now();
  while (ros::ok())
  {
    if (connect())
    {
      while (ros::ok())
      {
        try
        {
          ros::spinOnce();
          std::string esp_string = readSensor();
          if (esp_string == "")
          {
            continue;
          }
          std::vector<float> esp_data;
          try
          {
            esp_data = processData(esp_string);
          }
          catch (const std::exception& e)
          {
            continue;
          }
          std_msgs::Bool palletIsInPlace;

          // Filter data
          // std::cout << "esp_data_1: " << esp_data[0] << std::endl;
          // std::cout << "esp_data_2: " << esp_data[1] << std::endl;
          if (esp_data.size() != 7)
          {
            // palletIsInPlace.data = false;
            // palletInPlace_.publish(palletIsInPlace);
            rate_.sleep();
            continue;
          }
          else if (esp_data[0] < inplace_tolerance)
          {
            updatePalletPosition(esp_data);
            ros::Duration elapsed_time = ros::Time::now() - last_change_time;
            double change_amount = esp_data[0] - last_pose;

            if (fabs(change_amount) > 0.1)
            {
              last_pose = esp_data[0];
              last_change_time = ros::Time::now();
            }

            if ((ros::Time::now() - last_change_time).toSec() > 1.0)
            {
              palletIsInPlace.data = true;
              palletInPlace_.publish(palletIsInPlace);
              cout_connect_false = 0;
            }
            else
            {
              palletIsInPlace.data = false;
              palletInPlace_.publish(palletIsInPlace);
            }
          }
        }
        catch (const std::exception& e)
        {
          // cout_connect_false += 1;
          ROS_ERROR_ONCE("can't read sensor!: %s", e.what());
          break;
        }
        // if (cout_connect_false == 1)
        // {
        //   cout_connect_false = 0;
        //   break;
        // }
        rate_.sleep();
      }
    }
    else
    {
      ROS_ERROR("Reconnect to server...");
      // ros::Duration(2.0).sleep();
    }
  }
}