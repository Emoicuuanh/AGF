#include <boost/asio.hpp>    // Main Boost.Asio header for networking
#include <iostream>          // Standard input/output operations
#include <string>            // For handling strings

using boost::asio::ip::tcp;  // Define a shorter namespace for easier usage

int main()
{
    try
    {
        boost::asio::io_service io_service;  // Create an I/O service object
        tcp::socket socket(io_service);      // Create a TCP socket
        tcp::endpoint endpoint(boost::asio::ip::address::from_string("192.168.0.124"), 80);

        std::cout << "Connecting to server..." << std::endl;
        socket.connect(endpoint);  // Connect to the server
        std::cout << "Connected!" << std::endl;

        // Send a simple command
        std::string msg = "start_conveyor\r\n";
        boost::system::error_code ignored_error;
        boost::asio::write(socket, boost::asio::buffer(msg), ignored_error);

        // Receive response
        char reply[1024];
        size_t reply_length = boost::asio::read(socket, boost::asio::buffer(reply, 1024), ignored_error);
        std::cout << "Reply is: " << std::string(reply, reply_length) << std::endl;

        socket.close();  // Close the socket
    }
    catch (const std::exception& e)
    {
        std::cerr << "Exception: " << e.what() << std::endl;
    }

    return 0;
}
