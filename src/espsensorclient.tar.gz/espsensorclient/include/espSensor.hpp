#ifndef ESPSENSOR_HPP
#define ESPSENSOR_HPP

#include <boost/asio.hpp>
#include <boost/asio/steady_timer.hpp>
#include <geometry_msgs/Point.h>
#include <geometry_msgs/Pose.h>
#include <geometry_msgs/TransformStamped.h>
#include <iostream>
#include <mutex>
#include <ros/ros.h>
#include <std_msgs/Bool.h>
#include <std_msgs/Float32.h>
#include <std_msgs/Float32MultiArray.h>
#include <std_stamped_msgs/StringService.h>
#include <string>
#include <tf2/LinearMath/Quaternion.h>
#include <tf2_ros/static_transform_broadcaster.h>
#include <tf2_ros/transform_broadcaster.h>
#include <thread>

class EspSensor
{
private:
  std::string server_ip_;
  int port_;
  boost::asio::io_service io_service_;
  boost::asio::ip::tcp::socket socket_;
  std::vector<std::string> stringData_;

  ros::NodeHandle nh_;
  ros::Rate rate_;

  std::mutex tcp_mutex_;  //lock TCP for service callback

  ros::Publisher palletInPlace_ =
      nh_.advertise<std_msgs::Bool>("palletInPlace", 10);
  // ros::Subscriber palletWidth_ = nh_.subscribe("pallet_width", 10, &EspSensor::palletWidthCallback, this);
  ros::ServiceServer reqUpdateWidthSrv = nh_.advertiseService(
      "esp_server/update_pallet_width", &EspSensor::palletWidthReqCb, this);
  ros::ServiceServer reqConveyorCtrlSrv = nh_.advertiseService(
      "esp_server/conveyor_control", &EspSensor::conveyorControlReqCb, this);

  tf2_ros::StaticTransformBroadcaster static_broadcaster_;
  tf2_ros::TransformBroadcaster transform_broadcaster_;
  geometry_msgs::TransformStamped sensor_static_transform;
  geometry_msgs::TransformStamped pallet_transform;
  geometry_msgs::TransformStamped edge_pallet_transform;
  geometry_msgs::TransformStamped pCorrectAngle_transform;
  geometry_msgs::TransformStamped pPick_transform;
  geometry_msgs::TransformStamped pTurn_transform;
  geometry_msgs::TransformStamped pWait_transform;

  geometry_msgs::Pose currentPalletTf;
  geometry_msgs::Pose currentPalletPose;
  geometry_msgs::Pose espSensorTf1;

  float pallet_width = 0.0;
  std::string sensor1_frame = "";
  std::string base_frame = "";
  std::string pallet_frame = "pallet";
  bool done_update_width_ = false;
  std::string data_frame = "";

  double sensor1_x, sensor1_y, sensor1_z, sensor2_x, sensor2_y, sensor2_z,
      sensor_distance, inplace_tolerance;  // sensor position
  double sensor1_qx, sensor1_qy, sensor1_qz, sensor1_qw;
  double pick_frame_x, pick_frame_y, pick_frame_z;
  double turn_frame_x, turn_frame_y, turn_frame_z;
  double wait_frame_x, wait_frame_y, wait_frame_z;
  double correct_angle_frame_x, correct_angle_frame_y, correct_angle_frame_z;
  bool connect();
  std::string readSensor();
  std::vector<float> processData(const std::string& input);
  std::string processResponse(const std::string& input);

  void getInitParameters();
  geometry_msgs::Pose calculatePalletPosition(std::vector<float>& sensorData_);
  void updatePalletPosition(std::vector<float>& sensorData_);
  void publishSensorFrame();
  tf2::Quaternion eulerToQuaternion(float roll, float pitch, float yaw);
  bool palletWidthReqCb(std_stamped_msgs::StringService::Request& req,
                        std_stamped_msgs::StringService::Response& res);
  bool conveyorControlReqCb(std_stamped_msgs::StringService::Request& req,
                            std_stamped_msgs::StringService::Response& res);
  std::string sendCommandToESP32(const std::string& command);

  std::string cleanString(const std::string& input)
  {
    std::string result;
    for (char c : input)
    {
      if (c != '\r' && c != '\n')
      {
        result += c;
      }
    }
    return result;
  }

public:
  EspSensor(const std::string& server_ip, int port, ros::NodeHandle nh,
            ros::Rate rate)
      : server_ip_(server_ip), port_(port), socket_(io_service_), nh_(nh),
        rate_(rate) {};
  ~EspSensor() {};

  void startClient();
};
#endif